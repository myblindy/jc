﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace jc
{
    class Parser
    {
        protected Lexer lexer;
        protected Lexer.Token lookahead;
        protected StreamWriter output;

        public Parser(Stream stream)
        {
            lexer = new Lexer(stream);
            output = File.CreateText("output.txt");
        }

        /// <summary>
        /// Logs a line of text
        /// </summary>
        /// <param name="line">The line of text to be logged</param>
        protected void Log(string line)
        {
            output.WriteLine(line);
            Console.WriteLine(line);
        }

        /// <summary>
        /// Logs a syntax error
        /// </summary>
        /// <param name="error">The syntax error message</param>
        protected void SyntaxError(string error)
        {
            Log(string.Format("** Syntax error:{0}", error));
        }

        /// <summary>
        /// Logs a warning
        /// </summary>
        /// <param name="warning">The warning messge</param>
        protected void Warning(string warning)
        {
            Log(string.Format("*  Warning:{0}", warning));
        }

        /// <summary>
        /// The main function. Runs the parser over the stream and 
        /// returns whether or not the stream is valid.
        /// </summary>
        /// <returns>A bool indicating whether or not the stream is valid syntactically</returns>
        public bool Parse()
        {
            lookahead = lexer.GetNextToken();
            if (NTF_Prog() && Match(Lexer.Token.TokenType.EndOfFile))
            {
                output.Close();
                return true;
            }
            else
            {
                output.Close();
                return false;
            }
        }

        /// <summary>
        /// Tests whether the lookahead is in the token list
        /// </summary>
        /// <param name="tokens">The list of tokens given as either string, Lexer.Token.TokenType or Lexer.Token</param>
        /// <returns>A bool representing whether or not the lookahead is in the list</returns>
        protected bool ValidLookAhead(object[] tokens)
        {
            foreach (object o in tokens)
                if (o is string)
                {
                    if (lookahead.Value == (string)o)
                        return true;
                }
                else if (o is Lexer.Token.TokenType)
                {
                    if (lookahead.Type == (Lexer.Token.TokenType)o)
                        return true;
                }
                else if (o is Lexer.Token)
                {
                    if (lookahead.Type == ((Lexer.Token)o).Type && lookahead.Value == ((Lexer.Token)o).Value)
                        return true;
                }
                else
                    throw new InvalidDataException(
                        "Encountered an invalid token type in the first/follow token list");

            return false;
        }

        /// <summary>
        /// Skips all the errors until the next (maybe valid) token
        /// </summary>
        /// <param name="tokens">The list of "valid" tokens</param>
        /// <returns>true if there has been an error that was skipped, false otherwise</returns>
        protected bool SkipErrors(params object[] tokens)
        {
            if (ValidLookAhead(tokens))
                return false;

            SyntaxError(string.Format("{0}:unexpected token '{1}'",
                lookahead.Line, lookahead.Value));

            do
            {
                lookahead = lexer.GetNextToken();
            } while (!ValidLookAhead(tokens));

            Warning(string.Format("{0}:Resuming parsing near the token '{1}'",
                lookahead.Line, lookahead.Value));

            return true;
        }

        // <prog> ::= <classdeclstar><progbody>
        protected bool NTF_Prog()
        {
            bool error = SkipErrors("class", "program", Lexer.Token.TokenType.EndOfFile);

            if (NTF_ClassDeclStar() && NTF_ProgBody())
                Log("<prog> ::= <classdeclstar><progbody>");
            else
                error = true;

            return !error;
        }

        // <progbody> ::= program <funcbody>;<functionstar>
        // MODIFIED
        // <progbody> ::= program <funcbody>;<definitionstar>
        protected bool NTF_ProgBody()
        {
            bool error = SkipErrors("program", Lexer.Token.TokenType.EndOfFile);

            if (Match("program") && NTF_FuncBody() && Match(Lexer.Token.TokenType.Semicolon)
                && NTF_DefinitionStar())
                Log("<progbody> ::= program <funcbody> ; <definitionstar>");
            else
                error = true;

            return !error;
        }

        /*
                // <functionstar> ::= e | <function><functionstar>
                protected bool NTF_FunctionStar()
                {
                    // first(<functionstar>)=first(<function>)=first(<funchead>)=first(<type>)
                    if (lookahead.Value == "int" || lookahead.Value == "float" || lookahead.Type == Lexer.Token.TokenType.Identifier)
                        if (NTF_Function() && NTF_FunctionStar())
                        {
                            Log("<functionstar> ::= <function><functionstar>");
                            return true;
                        }
                        else
                            return false;
                    // follow(<functionstar>)=}+$
                    else if (lookahead.Type == Lexer.Token.TokenType.CloseBrace || lookahead.Type == Lexer.Token.TokenType.EndOfFile)
                    {
                        Log("<functionstar> ::= e");
                        return true;
                    }
                    else
                        return false;
                }

                // <function> ::= <funchead><funcbody>;
                protected bool NTF_Function()
                {
                    if (NTF_FuncHead() && NTF_FuncBody() && Match(Lexer.Token.TokenType.Semicolon))
                    {
                        Log("<function> ::= <funchead><funcbody>;");
                        return true;
                    }
                    else
                        return false;
                }
        */

        // <funcbody> ::= {<typedeclstar><statementstar>}
        protected bool NTF_FuncBody()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.OpenBrace, Lexer.Token.TokenType.Semicolon);

            if (Match(Lexer.Token.TokenType.OpenBrace) && NTF_TypeDeclStar() && NTF_StatementStar()
                && Match(Lexer.Token.TokenType.CloseBrace))
                Log("<funcbody> ::= {<typedeclstar><statementstar>}");
            else
                error = true;

            return !error;
        }

        // <statementstar> ::= e | <statement><statementstar>
        protected bool NTF_StatementStar()
        {
            bool error = SkipErrors("if", "for", "cin", "cout", "return", Lexer.Token.TokenType.Identifier,
                Lexer.Token.TokenType.CloseBrace);

            // first(<statement>)=first(<variable>)+if+for+cin+cout+return
            //                   =first(<idnest>)+id+if+for+cin+cout+return
            //                   =id+if+for+cin+cout+return
            if (lookahead.Value == "if" || lookahead.Value == "for" || lookahead.Value == "cin" || lookahead.Value == "cout"
                || lookahead.Value == "return" || lookahead.Type == Lexer.Token.TokenType.Identifier)
                if (NTF_Statement() && NTF_StatementStar())
                    Log("<statementstar> ::= <statement><statementstar>");
                else
                    error = true;
            // follow(<statementstar>)=}
            else if (lookahead.Type == Lexer.Token.TokenType.CloseBrace)
                Log("<statementstar> ::= e");
            else
                error = true;

            return !error;
        }

        // <statement> ::= <variable> := <expr>
        //               | if ( <expr> ) then <statblock> else <statblock> fi ;
        //               | for ( <statement> ; <expr> ; <statement> ) <statblock> ;
        //               | cin ( <variable> ) ;
        //               | cout ( <expr> ) ;
        //               | return ( <expr> ) ;
        protected bool NTF_Statement()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Identifier, "if", "for", "cin", "cout", "return",
                Lexer.Token.TokenType.CloseBrace, Lexer.Token.TokenType.Semicolon, "else", "fi");

            // first(<variable>)
            if (lookahead.Type == Lexer.Token.TokenType.Identifier)
                if (NTF_Variable() && Match(Lexer.Token.TokenType.Assignement) && NTF_Expr() && Match(Lexer.Token.TokenType.Semicolon))
                    Log("<statement> ::= <variable> := <expr>");
                else
                    error = true;
            else if (lookahead.Value == "if")
                if (Match("if") && Match(Lexer.Token.TokenType.OpenBracket) && NTF_Expr() && Match(Lexer.Token.TokenType.CloseBracket)
                    && Match("then") && NTF_StatBlock() && Match("else") && NTF_StatBlock() && Match("fi")
                    && Match(Lexer.Token.TokenType.Semicolon))
                    Log("<statement> ::= if ( <expr> ) then <statblock> else <statblock> fi ;");
                else
                    error = true;
            else if (lookahead.Value == "for")
                if (Match("for") && Match(Lexer.Token.TokenType.OpenBracket) && NTF_Statement() && Match(Lexer.Token.TokenType.Semicolon)
                    && NTF_Expr() && Match(Lexer.Token.TokenType.Semicolon) && NTF_Statement()
                    && Match(Lexer.Token.TokenType.CloseBracket) && NTF_StatBlock() && Match(Lexer.Token.TokenType.Semicolon))
                    Log("<statement> ::= for ( <statement> ; <expr> ; <statement> ) <statblock> ;");
                else
                    error = true;
            else if (lookahead.Value == "cin")
                if (Match("cin") && Match(Lexer.Token.TokenType.OpenBracket) && NTF_Variable()
                    && Match(Lexer.Token.TokenType.CloseBracket) && Match(Lexer.Token.TokenType.Semicolon))
                    Log("<statement> ::= cin ( <variable> ) ;");
                else
                    error = true;
            else if (lookahead.Value == "cout")
                if (Match("cout") && Match(Lexer.Token.TokenType.OpenBracket) && NTF_Expr()
                    && Match(Lexer.Token.TokenType.CloseBracket) && Match(Lexer.Token.TokenType.Semicolon))
                    Log("<statement> ::= cout ( <expr> ) ;");
                else
                    error = true;
            else if (lookahead.Value == "return")
                if (Match("return") && Match(Lexer.Token.TokenType.OpenBracket) && NTF_Expr()
                    && Match(Lexer.Token.TokenType.CloseBracket) && Match(Lexer.Token.TokenType.Semicolon))
                    Log("<statement> ::= return ( <expr> ) ;");
                else
                    error = true;

            return !error;
        }

        // <statblock> ::= { <statementstar> } | <statement> | e
        protected bool NTF_StatBlock()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.OpenBrace, "if", "for", "cin", "cout", "return", Lexer.Token.TokenType.Identifier,
                "else", "fi", Lexer.Token.TokenType.Semicolon);

            if (lookahead.Type == Lexer.Token.TokenType.OpenBrace)
                if (Match(Lexer.Token.TokenType.OpenBrace) && NTF_StatementStar()
                    && Match(Lexer.Token.TokenType.CloseBrace))
                    Log("<statblock> ::= { <statementstar> }");
                else
                    error = true;
            // first(<statementstar>)
            else if (lookahead.Value == "if" || lookahead.Value == "for" || lookahead.Value == "cin" || lookahead.Value == "cout"
                || lookahead.Value == "return" || lookahead.Type == Lexer.Token.TokenType.Identifier)
                if (NTF_Statement())
                    Log("<statblock> ::= <statement>");
                else
                    error = true;
            // follow(<statblock>)=else+fi+;
            else if (lookahead.Value == "else" || lookahead.Value == "fi" || lookahead.Type == Lexer.Token.TokenType.Semicolon)
                Log("<statblock> ::= e");
            else
                error = true;

            return !error;
        }

        // <expr> ::= <arithexpr><expr2>
        protected bool NTF_Expr()
        {
            bool error = SkipErrors("+", "-", Lexer.Token.TokenType.Identifier, Lexer.Token.TokenType.Number,
                Lexer.Token.TokenType.OpenBracket, Lexer.Token.TokenType.Not,
                Lexer.Token.TokenType.Semicolon, Lexer.Token.TokenType.CloseBracket);

            if (NTF_ArithExpr() && NTF_Expr2())
                Log("<expr> ::= <arithexpr> <expr2>");
            else
                error = true;

            return !error;
        }

        // <arithexpr> ::= <term> <arithexpr2> | <sign> <term> <arithexpr2>
        protected bool NTF_ArithExpr()
        {
            bool error = SkipErrors("+", "-", Lexer.Token.TokenType.Identifier, Lexer.Token.TokenType.Number,
                Lexer.Token.TokenType.OpenBracket, Lexer.Token.TokenType.Not,
                Lexer.Token.TokenType.Comparison, Lexer.Token.TokenType.Additive, Lexer.Token.TokenType.CloseSquareBracket,
                Lexer.Token.TokenType.Comma, Lexer.Token.TokenType.CloseBracket, Lexer.Token.TokenType.Semicolon);

            // first(<term>)=first(<variable>)+num+(+!
            if (lookahead.Type == Lexer.Token.TokenType.Identifier || lookahead.Type == Lexer.Token.TokenType.Number
                || lookahead.Type == Lexer.Token.TokenType.OpenBracket || lookahead.Type == Lexer.Token.TokenType.Not)
                if (NTF_Term() && NTF_ArithExpr2())
                    Log("<arithexpr> ::= <term> <arithexpr2>");
                else
                    error = true;
            else if (lookahead.Value == "+" || lookahead.Value == "-")
                if (NTF_Sign() && NTF_Term() && NTF_ArithExpr2())
                    Log("<arithexpr> ::= <sign> <term> <arithexpr2>");
                else
                    error = true;

            return !error;
        }

        // <sign> ::= + | -
        protected bool NTF_Sign()
        {
            bool error = SkipErrors("+", "-",
                Lexer.Token.TokenType.Identifier, Lexer.Token.TokenType.Number, Lexer.Token.TokenType.OpenBracket,
                Lexer.Token.TokenType.Not);

            if (lookahead.Value == "+")
                if (Match("+"))
                    Log("<sign> ::= +");
                else
                    error = true;
            else if (Match("-"))
                Log("<sign> ::= -");
            else
                error = true;

            return false;
        }

        // <arithexpr2> ::= e | addop <term><arithexpr2>
        protected bool NTF_ArithExpr2()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Additive,
                Lexer.Token.TokenType.Semicolon, Lexer.Token.TokenType.CloseBracket, Lexer.Token.TokenType.Comparison,
                Lexer.Token.TokenType.CloseSquareBracket, Lexer.Token.TokenType.Comma);

            // first(<arithexpr2>)=addop
            if (lookahead.Type == Lexer.Token.TokenType.Additive)
                if (Match(Lexer.Token.TokenType.Additive) && NTF_Term() && NTF_ArithExpr2())
                    Log("<arithexpr2> ::= addop <term> <arithexpr2>");
                else
                    error = true;
            // follow(<arithexpr2>)=follow(<arithexpr>)=follow(<expr>)+relop+addop+]+,+follow(<aparams>)
            //                     =;+)+relop+addop+]+,
            else if (lookahead.Type == Lexer.Token.TokenType.Semicolon || lookahead.Type == Lexer.Token.TokenType.CloseBracket
                || lookahead.Type == Lexer.Token.TokenType.Additive || lookahead.Type == Lexer.Token.TokenType.Comparison
                || lookahead.Type == Lexer.Token.TokenType.CloseSquareBracket || lookahead.Type == Lexer.Token.TokenType.Comma)
                Log("<arithexpr2> ::= e");
            else
                error = true;

            return !error;
        }

        // <term> ::= <factor> <term2>
        protected bool NTF_Term()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Identifier, Lexer.Token.TokenType.OpenBracket, Lexer.Token.TokenType.Not,
                Lexer.Token.TokenType.Number,
                Lexer.Token.TokenType.Multiplicative, Lexer.Token.TokenType.Comma, Lexer.Token.TokenType.CloseBracket,
                Lexer.Token.TokenType.Comparison, Lexer.Token.TokenType.Additive, Lexer.Token.TokenType.Semicolon);

            if (NTF_Factor() && NTF_Term2())
                Log("<term> ::= <factor> <term2>");
            else
                error = false;

            return !error;
        }

        // <term2> ::= e | multop <factor> <term2>
        protected bool NTF_Term2()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Multiplicative,
                Lexer.Token.TokenType.Semicolon, Lexer.Token.TokenType.CloseBracket, Lexer.Token.TokenType.Additive,
                Lexer.Token.TokenType.Comparison, Lexer.Token.TokenType.CloseSquareBracket, Lexer.Token.TokenType.Comma);

            if (lookahead.Type == Lexer.Token.TokenType.Multiplicative)
                if (Match(Lexer.Token.TokenType.Multiplicative) && NTF_Factor() && NTF_Term2())
                    Log("<term2> ::= multop <factor> <term2>");
                else
                    error = true;
            // follow(<term2>)=follow(<term>)=follow(<arithexpr>)=;+)+relop+addop+]+,
            else if (lookahead.Type == Lexer.Token.TokenType.Semicolon || lookahead.Type == Lexer.Token.TokenType.CloseBracket
                || lookahead.Type == Lexer.Token.TokenType.Additive || lookahead.Type == Lexer.Token.TokenType.Comparison
                || lookahead.Type == Lexer.Token.TokenType.CloseSquareBracket || lookahead.Type == Lexer.Token.TokenType.Comma)
                Log("<term2> ::= e");
            else
                error = true;

            return !error;
        }

        // <factor> ::= <idnest> <factor2>
        //            | num
        //            | ( <expr> )
        //            | ! <factor>
        protected bool NTF_Factor()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Identifier, Lexer.Token.TokenType.Number, Lexer.Token.TokenType.OpenBracket,
                Lexer.Token.TokenType.Not, Lexer.Token.TokenType.Multiplicative, Lexer.Token.TokenType.Comparison,
                Lexer.Token.TokenType.Additive, Lexer.Token.TokenType.Comma, Lexer.Token.TokenType.CloseBracket,
                Lexer.Token.TokenType.Semicolon);

            // first(<idneststar>)=id
            if (lookahead.Type == Lexer.Token.TokenType.Identifier)
                if (NTF_IdNest() && NTF_Factor2())
                    Log("<factor> ::= <idneststar> id <factor2>");
                else
                    error = true;
            else if (lookahead.Type == Lexer.Token.TokenType.Number)
                if (Match(Lexer.Token.TokenType.Number))
                    Log("<factor> ::= num");
                else
                    error = true;
            else if (lookahead.Type == Lexer.Token.TokenType.OpenBracket)
                if (Match(Lexer.Token.TokenType.OpenBracket) && NTF_Expr() && Match(Lexer.Token.TokenType.CloseBracket))
                    Log("<factor> ::= ( <expr> )");
                else
                    error = true;
            else if (lookahead.Type == Lexer.Token.TokenType.Not)
                if (Match(Lexer.Token.TokenType.Not) && NTF_Factor())
                    Log("<factor> ::= ! <factor>");
                else
                    error = true;

            return !error;
        }

        // <factor2> ::= <indicestar>
        //             | ( <aparams> )
        protected bool NTF_Factor2()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.OpenSquareBracket, Lexer.Token.TokenType.Multiplicative,
                Lexer.Token.TokenType.Additive, Lexer.Token.TokenType.Comma, Lexer.Token.TokenType.CloseBracket,
                Lexer.Token.TokenType.Comparison, Lexer.Token.TokenType.Semicolon, Lexer.Token.TokenType.OpenBracket);

            // first(<factor2>.1)=first(<indicestar>)+follow(<factor2>)
            // =[+multop+addop+,+)+;
            if (lookahead.Type == Lexer.Token.TokenType.OpenSquareBracket || lookahead.Type == Lexer.Token.TokenType.Multiplicative
                || lookahead.Type == Lexer.Token.TokenType.Additive || lookahead.Type == Lexer.Token.TokenType.Comma
                || lookahead.Type == Lexer.Token.TokenType.CloseBracket || lookahead.Type == Lexer.Token.TokenType.Comparison
                || lookahead.Type == Lexer.Token.TokenType.Semicolon)
                if (NTF_IndiceStar())
                    Log("<factor2> ::= <indicestar>");
                else
                    error = true;
            else if (lookahead.Type == Lexer.Token.TokenType.OpenBracket)
                if (Match(Lexer.Token.TokenType.OpenBracket) && NTF_AParams() && Match(Lexer.Token.TokenType.CloseBracket))
                    Log("<factor2> ::= ( <aparams> )");
                else
                    error = true;

            return !error;
        }

        // <aparams> ::= <arithexpr> <aparamstailstar> | e
        protected bool NTF_AParams()
        {
            bool error = SkipErrors("+", "-", Lexer.Token.TokenType.Identifier, Lexer.Token.TokenType.Number,
                Lexer.Token.TokenType.OpenBracket, Lexer.Token.TokenType.Not, Lexer.Token.TokenType.CloseBracket);

            // first(<arithexpr>)=++-+first(<term>)=++-+id+num+(+!
            if (lookahead.Value == "+" || lookahead.Value == "-" || lookahead.Type == Lexer.Token.TokenType.Identifier
                || lookahead.Type == Lexer.Token.TokenType.Number || lookahead.Type == Lexer.Token.TokenType.OpenBracket
                || lookahead.Type == Lexer.Token.TokenType.Not)
                if (NTF_ArithExpr() && NTF_AParamsTailStar())
                    Log("<aparams> ::= <arithexpr> <aparamstail>");
                else
                    error = true;
            // follow = )
            else if (lookahead.Type == Lexer.Token.TokenType.CloseBracket)
                Log("<aparams> ::= e");
            else
                error = true;

            return !error;
        }

        // <aparamstailstar> ::= e | <aparamstail> <aparamstailstar>
        protected bool NTF_AParamsTailStar()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Comma, Lexer.Token.TokenType.CloseBracket);

            if (lookahead.Type == Lexer.Token.TokenType.Comma)
                if (NTF_AParamsTail() && NTF_AParamsTailStar())
                    Log("<aparamstailstar> ::= <apramstail> <aparamstailstar>");
                else
                    error = true;
            // follow=)
            else if (lookahead.Type == Lexer.Token.TokenType.CloseBracket)
                Log("<aparamstailstar> ::= e");
            else
                error = true;

            return !error;
        }

        // <apramstail> ::= , <arithexpr> | e
        protected bool NTF_AParamsTail()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Comma, Lexer.Token.TokenType.CloseBracket);

            if (lookahead.Type == Lexer.Token.TokenType.Comma)
                if (Match(Lexer.Token.TokenType.Comma) && NTF_ArithExpr())
                    Log("<aparamstail> ::= , <arithexpr>");
                else
                    error = true;
            else if (lookahead.Type == Lexer.Token.TokenType.CloseBracket)
                Log("<araparmstail> ::= e");
            else
                error = true;

            return !error;
        }

        // <indicestar> ::= e | <indice> <indicestar>
        protected bool NTF_IndiceStar()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.OpenSquareBracket,
                Lexer.Token.TokenType.Dot, Lexer.Token.TokenType.Assignement, Lexer.Token.TokenType.CloseBracket,
                Lexer.Token.TokenType.Multiplicative, Lexer.Token.TokenType.Additive, Lexer.Token.TokenType.Comma,
                Lexer.Token.TokenType.Comparison, Lexer.Token.TokenType.Semicolon, Lexer.Token.TokenType.OpenBracket,
                Lexer.Token.TokenType.Identifier);

            if (lookahead.Type == Lexer.Token.TokenType.OpenSquareBracket)
                if (NTF_Indice() && NTF_IndiceStar())
                    Log("<indicestar> ::= <indice> <indicestar>");
                else
                    error = true;
            // follow(indicestar)=.+:=+)+multop+addop+,+relop+;+(
            else if (lookahead.Type == Lexer.Token.TokenType.Dot || lookahead.Type == Lexer.Token.TokenType.Assignement
                || lookahead.Type == Lexer.Token.TokenType.CloseBracket || lookahead.Type == Lexer.Token.TokenType.Multiplicative
                || lookahead.Type == Lexer.Token.TokenType.Additive || lookahead.Type == Lexer.Token.TokenType.Comma
                || lookahead.Type == Lexer.Token.TokenType.Comparison || lookahead.Type == Lexer.Token.TokenType.Semicolon
                || lookahead.Type == Lexer.Token.TokenType.OpenBracket || lookahead.Type == Lexer.Token.TokenType.Identifier)
                Log("<indicestar> ::= e");
            else
                error = true;

            return !error;
        }

        // <indice> ::= [ <arithexpr> ] | e
        protected bool NTF_Indice()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.OpenSquareBracket,
                Lexer.Token.TokenType.Identifier, Lexer.Token.TokenType.Dot, Lexer.Token.TokenType.Assignement,
                Lexer.Token.TokenType.CloseBracket, Lexer.Token.TokenType.Multiplicative, Lexer.Token.TokenType.Additive,
                Lexer.Token.TokenType.Comma);

            if (lookahead.Type == Lexer.Token.TokenType.OpenSquareBracket)
                if (Match(Lexer.Token.TokenType.OpenSquareBracket) && NTF_ArithExpr() && Match(Lexer.Token.TokenType.CloseSquareBracket))
                    Log("<indice> ::= [ <arithexpr> ]");
                else
                    error = true;
            // follow=.+follow(variable)=.+:=+)+multop+addop+,+id
            else if (lookahead.Type == Lexer.Token.TokenType.Identifier || lookahead.Type == Lexer.Token.TokenType.Dot
                || lookahead.Type == Lexer.Token.TokenType.Assignement || lookahead.Type == Lexer.Token.TokenType.CloseBracket
                || lookahead.Type == Lexer.Token.TokenType.Multiplicative || lookahead.Type == Lexer.Token.TokenType.Additive
                || lookahead.Type == Lexer.Token.TokenType.Comma)
                Log("<indice> ::= e");
            else
                error = true;

            return !error;
        }

        // <idnest> ::= id <idnest2>
        // made it to read the name of the method/class im calling too
        // MODIFIED 
        // <idnest> ::= id <indicestar> <idnest2>
        protected bool NTF_IdNest()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Identifier,
                Lexer.Token.TokenType.OpenSquareBracket, Lexer.Token.TokenType.OpenBracket, Lexer.Token.TokenType.Dot,
                Lexer.Token.TokenType.Semicolon, Lexer.Token.TokenType.CloseBracket, Lexer.Token.TokenType.Comparison,
                Lexer.Token.TokenType.Additive, Lexer.Token.TokenType.CloseSquareBracket, Lexer.Token.TokenType.Comma,
                Lexer.Token.TokenType.Assignement, Lexer.Token.TokenType.Multiplicative);

            if (Match(Lexer.Token.TokenType.Identifier) && NTF_IndiceStar() && NTF_IdNest2())
                Log("<idnest> ::= id <indicestar> <idnest2>");
            else
                error = true;

            return !error;
        }

        // <idnest2> ::= <indicestar> . <idnest> | e
        // MODIFIED
        // <idnest2> ::= . <idnest> | e
        protected bool NTF_IdNest2()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Dot,
                Lexer.Token.TokenType.OpenSquareBracket, Lexer.Token.TokenType.OpenBracket, Lexer.Token.TokenType.Dot,
                Lexer.Token.TokenType.Semicolon, Lexer.Token.TokenType.CloseBracket, Lexer.Token.TokenType.Comparison,
                Lexer.Token.TokenType.Additive, Lexer.Token.TokenType.CloseSquareBracket, Lexer.Token.TokenType.Comma,
                Lexer.Token.TokenType.Assignement, Lexer.Token.TokenType.Multiplicative);

            // first(<idnest2>.1)=.
            if (lookahead.Type == Lexer.Token.TokenType.Dot)
                if (Match(Lexer.Token.TokenType.Dot) && NTF_IdNest())
                    Log("<idnest2> ::= . <idnest>");
                else
                    error = true;
            // follow(idnest2)=follow(idnest)=[+follow(variable)+(=[+(+:=+)+follow(factor)
            //                =[+(+:=+)+follow(term)=[+(+:=+)+addop+multop+follow(arithexpr)
            //                =;+)+relop+addop+]+,+[+(+:=+multop
            else if (lookahead.Type == Lexer.Token.TokenType.Semicolon || lookahead.Type == Lexer.Token.TokenType.CloseBracket ||
                lookahead.Type == Lexer.Token.TokenType.Comparison || lookahead.Type == Lexer.Token.TokenType.Additive ||
                lookahead.Type == Lexer.Token.TokenType.CloseSquareBracket || lookahead.Type == Lexer.Token.TokenType.Comma ||
                lookahead.Type == Lexer.Token.TokenType.OpenSquareBracket || lookahead.Type == Lexer.Token.TokenType.OpenBracket ||
                lookahead.Type == Lexer.Token.TokenType.OpenSquareBracket || lookahead.Type == Lexer.Token.TokenType.Assignement ||
                lookahead.Type == Lexer.Token.TokenType.Multiplicative)
                Log("<idnest2> ::= e");
            else
                error = true;

            return !error;
        }

        // <expr2> ::= e | relop <arithexpr>
        protected bool NTF_Expr2()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Comparison,
                Lexer.Token.TokenType.Semicolon, Lexer.Token.TokenType.CloseBracket);

            // first(<expr2>)=relop
            if (lookahead.Type == Lexer.Token.TokenType.Comparison)
                if (Match(Lexer.Token.TokenType.Comparison) && NTF_ArithExpr())
                    Log("<expr2> ::= relop <arithexpr>");
                else
                    error = true;
            // follow(<expr2>)=follow(<expr>)=;+)
            else if (lookahead.Type == Lexer.Token.TokenType.Semicolon || lookahead.Type == Lexer.Token.TokenType.CloseBracket)
                Log("<expr2> ::= e");
            else
                error = true;

            return !error;
        }

        // <variable> ::= <idnest> <indicestar>
        protected bool NTF_Variable()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Identifier,
                Lexer.Token.TokenType.Assignement, Lexer.Token.TokenType.Multiplicative, Lexer.Token.TokenType.Additive,
                Lexer.Token.TokenType.Comparison, Lexer.Token.TokenType.Comma, Lexer.Token.TokenType.CloseBracket,
                Lexer.Token.TokenType.Semicolon);

            if (NTF_IdNest() && NTF_IndiceStar())
                Log("<variable> ::= <idnest> <indicestar>");
            else
                error = true;

            return !error;
        }

        /*
        // <funchead> ::= <type> id ( <fparams> )
        protected bool NTF_FuncHead()
        {
            if (NTF_Type() && Match(Lexer.Token.TokenType.Identifier) && Match(Lexer.Token.TokenType.OpenBracket)
                && NTF_FParams() && Match(Lexer.Token.TokenType.CloseBracket))
            {
                Log("<funchead> ::= <type> id ( <fparams> )");
                return true;
            }
            else
                return false;
        }
        */

        // <fparams> ::= <type> id <arraystar> <fparamstailstar> | e
        protected bool NTF_FParams()
        {
            bool error = SkipErrors("int", "float", Lexer.Token.TokenType.Identifier,
                Lexer.Token.TokenType.CloseBracket);

            if (lookahead.Value == "int" || lookahead.Value == "float" || lookahead.Type == Lexer.Token.TokenType.Identifier)
                if (NTF_Type() && Match(Lexer.Token.TokenType.Identifier) && NTF_ArrayStar() && NTF_FParamsTailStar())
                    Log("<fparams> ::= <type> id <arraystar> <fparamstailstar>");
                else
                    error = true;
            else if (lookahead.Type == Lexer.Token.TokenType.CloseBracket)
                Log("fparams> ::= e");
            else
                error = true;

            return !error;
        }

        // <fparamstailstar> ::= e | <fparamstail><fparamstairlstar>
        protected bool NTF_FParamsTailStar()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Comma,
                Lexer.Token.TokenType.CloseBracket);

            if (lookahead.Type == Lexer.Token.TokenType.Comma)
                if (NTF_FParamsTail() && NTF_FParamsTailStar())
                    Log("<fparamstailstar> ::= <fparamstail> <fparamstailstar>");
                else
                    error = true;
            else if (lookahead.Type == Lexer.Token.TokenType.CloseBracket)
                Log("<fparamstailstar> ::= e");
            else
                error = true;

            return !error;
        }

        // <fparamstail> ::= e | , <type> id <arraystar>
        protected bool NTF_FParamsTail()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Comma,
                Lexer.Token.TokenType.CloseBracket);

            if (lookahead.Type == Lexer.Token.TokenType.Comma)
                if (Match(Lexer.Token.TokenType.Comma) && NTF_Type() && Match(Lexer.Token.TokenType.Identifier)
                    && NTF_ArrayStar())
                    Log("<fparamstail> ::= , <type> id <arraystar>");
                else
                    error = true;
            else if (lookahead.Type == Lexer.Token.TokenType.CloseBracket)
                Log("<fparamstail> ::= e");
            else
                error = true;

            return !error;
        }

        // <arraystar> ::= e | <array> <arraystar>
        protected bool NTF_ArrayStar()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.OpenSquareBracket,
                Lexer.Token.TokenType.Semicolon, Lexer.Token.TokenType.Comma, Lexer.Token.TokenType.CloseBracket);

            if (lookahead.Type == Lexer.Token.TokenType.OpenSquareBracket)
                if (NTF_Array() && NTF_ArrayStar())
                    Log("<arraystar> ::= <array> <arraystar>");
                else
                    error = true;
            // follow=;+,+)
            else
                if (lookahead.Type == Lexer.Token.TokenType.Semicolon || lookahead.Type == Lexer.Token.TokenType.Comma
                    || lookahead.Type == Lexer.Token.TokenType.CloseBracket)
                    Log("<arraystar> ::= e");
                else
                    error = true;

            return !error;
        }

        // <array> ::= [ <int> ] | e
        protected bool NTF_Array()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.OpenSquareBracket,
                Lexer.Token.TokenType.Comma, Lexer.Token.TokenType.CloseBracket, Lexer.Token.TokenType.Semicolon);

            if (lookahead.Type == Lexer.Token.TokenType.OpenSquareBracket)
                if (Match(Lexer.Token.TokenType.OpenSquareBracket) && NTF_Int() && Match(Lexer.Token.TokenType.CloseSquareBracket))
                    Log("<array> ::= [ <int> ]");
                else
                    error=true;
            // follow=,+)+;
            else if (lookahead.Type == Lexer.Token.TokenType.Comma || lookahead.Type == Lexer.Token.TokenType.CloseBracket
                || lookahead.Type == Lexer.Token.TokenType.Semicolon)
                Log("<array> ::= e");
            else
                error=true;

            return !error;
        }

        protected bool NTF_Int()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Number,
                Lexer.Token.TokenType.CloseSquareBracket);

            if (lookahead.Type == Lexer.Token.TokenType.Number && lookahead.Value.IndexOf(".") < 0)
                if (Match(Lexer.Token.TokenType.Number))
                    Log("<int> ::= int");
                else
                    error = false;
            else 
                error = true;

            return !error;
        }

        // <typedeclstar> ::= e | <typedecl><typedeclstar>
        protected bool NTF_TypeDeclStar()
        {
            bool error = SkipErrors("int", "float", Lexer.Token.TokenType.Identifier,
                "if", "for", "cin", "cout", "return", Lexer.Token.TokenType.CloseBrace);

            // first(<typedecl>)
            if (lookahead.Type == Lexer.Token.TokenType.Identifier || lookahead.Value == "int" || lookahead.Value == "float")
            {
                // if the next token after the lookahead isnt id, skip to ::=e
                if (lexer.PeekNextToken().Type != Lexer.Token.TokenType.Identifier)
                    Log("<typedeclstar> ::= e (FORCED)");
                else if (NTF_TypeDecl() && NTF_TypeDeclStar())
                    Log("<typedeclstar> ::= <typedecl><typedeclstar>");
                else
                    error=true;
            }
            // follow(<typedeclstar>)=first(<statementstar)+}+first(functionstar)
            //                       =first(<statement>)+}+first(function)
            //                       =if|for|cin|cout|return|first(<variable>)|}|first(funchead)
            //                       =if+for+cin+cout+return+id+}+int+float
            else if (lookahead.Value == "if" || lookahead.Value == "for" || lookahead.Value == "cin"
                || lookahead.Value == "cout" || lookahead.Value == "return" || lookahead.Type == Lexer.Token.TokenType.CloseBrace
                || lookahead.Type == Lexer.Token.TokenType.Identifier || lookahead.Value == "int"
                || lookahead.Value == "float")
                Log("<typedeclstar> ::= e");
            else
                error=true;

            return !error;
        }

        // <typedecl> ::= <type> id <arraystar>;
        protected bool NTF_TypeDecl()
        {
            bool error = SkipErrors("int", "float", Lexer.Token.TokenType.Identifier,
                "if", "cin", "cout", "return", "for", Lexer.Token.TokenType.CloseBrace);

            if (NTF_Type() && Match(Lexer.Token.TokenType.Identifier) && NTF_ArrayStar() && Match(Lexer.Token.TokenType.Semicolon))
                Log("<typedecl> ::= <type> id <arraystar>;");
            else
                error = true;

            return !error;
        }

        // <type> ::= int | float | id
        protected bool NTF_Type()
        {
            bool error = SkipErrors("int", "float", Lexer.Token.TokenType.Identifier);

            if (lookahead.Value == "int")
                if (Match("int"))
                    Log("<type> ::= int");
                else
                    error = true;
            else if (lookahead.Value == "float")
                if (Match("float"))
                    Log("<type> ::= float");
                else
                    error = true;
            else if (lookahead.Type == Lexer.Token.TokenType.Identifier)
                if (Match(Lexer.Token.TokenType.Identifier))
                    Log("<type> ::= id");
                else
                    error=true;

            return !error;
        }

        // <classdeclstar> ::= e | <classdecl><classdeclstar>
        protected bool NTF_ClassDeclStar()
        {
            bool error = SkipErrors("class", "program");

            if (lookahead.Value == "class")                                    // first(<classdecl>)
                if (NTF_ClassDecl() && NTF_ClassDeclStar())
                    Log("<classdeclstar> ::= <classdecl><classdeclstar>");
                else
                    error = true;
            else
                if (lookahead.Value == "program")                              // follow(<classdecl>)
                    Log("<classdeclstar> ::= e");
                else
                    error = true;

            return !error;
        }

        // <classdecl> ::= class id { <typedeclstar> <functionstar> } ;
        // MODIFIED
        // <classdecl> ::= class id { <definitionstar> } ;
        protected bool NTF_ClassDecl()
        {
            /*
                        if (Match("class") && Match(Lexer.Token.TokenType.Identifier) && Match(Lexer.Token.TokenType.OpenBrace)
                            && NTF_TypeDeclStar() && NTF_FunctionStar() && Match(Lexer.Token.TokenType.CloseBrace)
                            && Match(Lexer.Token.TokenType.Semicolon))
                        {
                            Log("<classdecl> ::= class id {<typedeclstar><functionstar>};");
                            return true;
                        }
                        else
                            return false;
            */
            bool error = SkipErrors("class", "program");

            if (Match("class") && Match(Lexer.Token.TokenType.Identifier) && Match(Lexer.Token.TokenType.OpenBrace)
                && NTF_DefinitionStar() && Match(Lexer.Token.TokenType.CloseBrace) && Match(Lexer.Token.TokenType.Semicolon))
                Log("<classdecl> := class id { <definitionstar> } ;");
            else
                error = true;

            return !error;
        }

        // <definitionstar> ::= e | <definition> <definitionstar>
        protected bool NTF_DefinitionStar()
        {
            bool error = SkipErrors("int", "float", Lexer.Token.TokenType.Identifier, Lexer.Token.TokenType.CloseBrace,
                Lexer.Token.TokenType.EndOfFile);

            if (lookahead.Value == "int" || lookahead.Value == "float" || lookahead.Type == Lexer.Token.TokenType.Identifier)
                if (NTF_Definition() && NTF_DefinitionStar())
                    Log("<definitionstar> ::= <definition> <definitionstar>");
                else
                    error = true;
            // follow=}+$
            else if (lookahead.Type == Lexer.Token.TokenType.EndOfFile || lookahead.Type == Lexer.Token.TokenType.CloseBrace)
                Log("<definitionstar> ::= e");
            else
                error = true;

            return !error;
        }

        // <definition> ::= <type> id <definition2>
        protected bool NTF_Definition()
        {
            bool error = SkipErrors("int", "float", Lexer.Token.TokenType.Identifier, Lexer.Token.TokenType.CloseBrace,
                Lexer.Token.TokenType.EndOfFile);

            if (NTF_Type() && Match(Lexer.Token.TokenType.Identifier) && NTF_Definition2())
                Log("<definition> ::= <type> id <definition2>");
            else
                error = true;

            return !error;
        }

        // <definition2> ::= ( <fparams> ) <funcbody> ;
        //                 | <arraystar> ;
        protected bool NTF_Definition2()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.OpenBracket, Lexer.Token.TokenType.OpenSquareBracket,
                Lexer.Token.TokenType.Semicolon,
                Lexer.Token.TokenType.CloseBrace, Lexer.Token.TokenType.EndOfFile);

            if (lookahead.Type == Lexer.Token.TokenType.OpenBracket)
                if (Match(Lexer.Token.TokenType.OpenBracket) && NTF_FParams() && Match(Lexer.Token.TokenType.CloseBracket)
                    && NTF_FuncBody() && Match(Lexer.Token.TokenType.Semicolon))
                    Log("<definition2> ::= ( <fparams> ) <funcbody> ;");
                else
                    error = true;
            else if (lookahead.Type == Lexer.Token.TokenType.OpenSquareBracket || lookahead.Type == Lexer.Token.TokenType.Semicolon)
                if (NTF_ArrayStar() && Match(Lexer.Token.TokenType.Semicolon))
                    Log("<definition2> ::= <arraystar> ;");
                else
                    error = true;

            return !error;
        }

        protected bool Match(Lexer.Token.TokenType type)
        {
            return Match(null, type);
        }

        protected bool Match(string val)
        {
            return Match(val, null);
        }

        protected bool Match(string val, Lexer.Token.TokenType? type)
        {
            bool ok = true;

            if (val != null && lookahead.Value != val)
                ok = false;
            else if (type.HasValue && lookahead.Type != type.Value)
                ok = false;

            if (!ok)
                SyntaxError(string.Format("{0}: expected '{1}', got instead '{2}', a {3}",
                    lookahead.Line, val ?? type.Value.ToString(), lookahead.Value, lookahead.Type.ToString()));

            lookahead = lexer.GetNextToken();

            return ok;
        }
    }
}
