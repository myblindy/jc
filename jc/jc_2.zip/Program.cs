﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace jc
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Count() < 1)
            {
                Console.WriteLine("Usage: jc source.jc");
                return;
            }

            Parser parser=new Parser(File.OpenRead(args[0]));
            Console.WriteLine(parser.Parse()
                ? "No errors encountered."
                : "Some errors encountered.");
        }
    }
}
