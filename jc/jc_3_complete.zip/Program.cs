﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace jc
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Count() < 1)
            {
                Console.WriteLine("Usage: jc source.jc");
                return;
            }

            Parser parser=new Parser(args[0]);
            parser.Output[Parser.LogType.SymbolTable] = Console.Out;
            parser.Parse();

            Console.WriteLine("\nBuild {0}, {1} error{2} and {3} warning{4} encountered.", 
                (parser.Errors.Count+parser.Warnings.Count)>0?"failed":"succeeded", 
                parser.Errors.Count, parser.Errors.Count==1?"":"s", 
                parser.Warnings.Count, parser.Warnings.Count==1?"":"s");
        }
    }
}
