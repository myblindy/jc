﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace jc
{
    class Parser
    {
        protected Lexer lexer;
        protected Lexer.Token lookahead;
        public SortedDictionary<LogType, TextWriter> Output = new SortedDictionary<LogType, TextWriter>();

        public List<string> Errors { get; set; }
        public List<string> Warnings { get; set; }

        /// <summary>
        /// The class holding a symbol table
        /// </summary>
        public class SymbolTable
        {
            /// <summary>
            /// The name of the symbol table, "Global" for the global table
            /// </summary>
            public string ID { get; set; }

            /// <summary>
            /// The constructor of the symbol table class
            /// </summary>
            /// <param name="id">The ID given to it</param>
            public SymbolTable(string id)
            {
                Data = new SortedDictionary<string, Information>();
                Parent = null;
                ID = id;
            }

            /// <summary>
            /// The class that holds information about the object being tracked by the symbol table
            /// </summary>
            public class Information
            {
                public Information()
                {
                    Properties = new SortedDictionary<string, object>();
                }

                public enum EKind
                {
                    Class,
                    Function,
                    Variable,
                }

                /// <summary>
                /// The kind of the object, function, class or variable
                /// </summary>
                public EKind Kind { get; set; }

                /// <summary>
                /// The properties of the object. Possible values for the key are
                /// "variable_type", "variable_arrayindices", "class_symtable",
                /// "function_type", "function_parameters", "function_symtable"
                /// </summary>
                public SortedDictionary<string, object> Properties { get; set; }
            }

            /// <summary>
            /// The data being tracked by the symbol table, grouped by the key (the name)
            /// </summary>
            public SortedDictionary<string, Information> Data { get; set; }

            /// <summary>
            /// The parent of the symbol table, null for the global table
            /// </summary>
            public SymbolTable Parent { get; set; }

            /// <summary>
            /// Finds a symbol name, optionally looking up in the table hierarchy
            /// </summary>
            /// <param name="id">The name of the symbol to look up</param>
            /// <param name="recurse">Whether or not to recurse up the tree</param>
            /// <returns>The structure holding all the information about the item, or null if not found</returns>
            public Information Find(string id, bool recurse)
            {
                Information info;
                if (Data.TryGetValue(id, out info))
                    return info;
                else
                    if (recurse)
                        if (Parent != null)
                            return Parent.Find(id, recurse);
                        else
                            return null;
                    else
                        return null;
            }

            /// <summary>
            /// Adds a symbol to the symbol table
            /// </summary>
            /// <param name="id">The name of the symbol</param>
            /// <returns>The Information structure to be filled</returns>
            public Information Add(string id)
            {
                if (Data.ContainsKey(id))
                    return Data[id];

                Data.Add(id, new Information());

                return Data[id];
            }

            /// <summary>
            /// Creates a child symbol table for a class or a function,
            /// setting its parent pointer to this table
            /// </summary>
            /// <param name="id">The name of the child table</param>
            /// <returns>The newly created symbol table</returns>
            public SymbolTable CreateChild(string id)
            {
                SymbolTable child = new SymbolTable(id);
                child.Parent = this;

                return child;
            }

            /// <summary>
            /// Represents the symbol table as a string for easy debugging
            /// </summary>
            /// <param name="level">The indentation level</param>
            /// <returns></returns>
            public string ToString(int level)
            {
                StringBuilder output = new StringBuilder();
                string pad = "".PadRight(level * 2, ' ');

                output.AppendFormat("{0}{1}\r\n", pad, ID);
                output.AppendFormat("{0}{1}\r\n", pad, "".PadRight(ID.Length, '='));
                output.AppendFormat("{0}{1}\r\n", pad, "");

                foreach (KeyValuePair<string, Information> kvp in Data)
                {
                    output.AppendFormat("{0}- {1} {2}\r\n", pad, kvp.Value.Kind, kvp.Key);
                    switch (kvp.Value.Kind)
                    {
                        case Information.EKind.Class:
                            output.AppendFormat("{0}  Symbol Table:\r\n", pad);
                            output.Append((kvp.Value.Properties["class_symtable"] as SymbolTable).ToString(level + 1));
                            break;
                        case Information.EKind.Function:
                            output.AppendFormat("{0}  Type: {1}\r\n", pad, kvp.Value.Properties["function_type"]);
                            foreach (SemanticInfo.ParameterInfo pi in (List<SemanticInfo.ParameterInfo>)kvp.Value.Properties["function_parameters"])
                            {
                                string sizes = "";
                                foreach (string size in pi.ArrayIndices)
                                    sizes += "[" + size + "]";
                                output.AppendFormat("{0}  Parameter: {1} of type {2} and size {3}\r\n", pad, pi.Name, pi.Type, sizes == "" ? "<single item>" : sizes);
                            }
                            output.AppendFormat("{0}  Symbol Table:\r\n", pad);
                            output.Append((kvp.Value.Properties["function_symtable"] as SymbolTable).ToString(level + 1));
                            break;
                        case Information.EKind.Variable:
                            {
                                string sizes = "";
                                foreach (string size in kvp.Value.Properties["variable_arrayindices"] as string[])
                                    sizes += "[" + size + "]";

                                output.AppendFormat("{0}  Type: {1}\r\n", pad, kvp.Value.Properties["variable_type"]);
                                output.AppendFormat("{0}  Size: {1}\r\n", pad, sizes == "" ? "<single item>" : sizes);
                            }
                            break;
                        default:
                            output.AppendFormat("{0}  Cannot interpret {1}\r\n", pad, kvp.Value.Kind);
                            break;
                    }
                }

                return output.ToString();
            }

            /// <summary>
            /// Represents the symbol table as a string for easy debugging
            /// </summary>
            /// <returns></returns>
            public override string ToString()
            {
                return ToString(0);
            }
        }

        /// <summary>
        /// Holds the semantic information of the parsing nodes
        /// </summary>
        protected class SemanticInfo
        {
            /// <summary>
            /// Holds the parameter info for function processing
            /// </summary>
            public class ParameterInfo
            {
                /// <summary>
                /// The type of the parameter
                /// </summary>
                public string Type { get; set; }

                /// <summary>
                /// The name of the parameter
                /// </summary>
                public string Name { get; set; }

                /// <summary>
                /// Any array indices of the parameter
                /// </summary>
                public List<string> ArrayIndices { get; set; }

                /// <summary>
                /// Initializes the structure
                /// </summary>
                public ParameterInfo() { ArrayIndices = new List<string>(); }
            }

            /// <summary>
            /// Holds the parameters as a dictionary
            /// </summary>
            public List<ParameterInfo> Parameters { get; set; }

            /// <summary>
            /// The name of the structure being parsed
            /// </summary>
            public string Name { get; set; }

            /// <summary>
            /// The type of the structure being parsed
            /// </summary>
            public string Type { get; set; }

            /// <summary>
            /// The indices of the structure being parsed
            /// </summary>
            public List<string> ArrayIndices { get; set; }

            /// <summary>
            /// Initializes the structure
            /// </summary>
            public SemanticInfo()
            {
                Parameters = new List<ParameterInfo>();
                ArrayIndices = new List<string>();
            }
        }

        /// <summary>
        /// The global symbol table
        /// </summary>
        public SymbolTable Global = new SymbolTable("Global");

        /// <summary>
        /// The current symbol table (scope)
        /// </summary>
        protected SymbolTable CurrentScope;

        /// <summary>
        /// Constructs the parser
        /// </summary>
        /// <param name="file">The file name to parse</param>
        public Parser(string file)
        {
            lexer = new Lexer(File.ReadAllText(file));
            Errors = new List<string>();
            Warnings = new List<string>();
            CurrentScope = Global;

            int pos = file.LastIndexOf('.');
            string realname = pos >= 0 ? file.Substring(0, pos) : file;

            Output.Add(LogType.Parse, File.CreateText(realname + "_parseinfo.txt"));
            Output.Add(LogType.SymbolTable, File.CreateText(realname + "_symboltable.txt"));
            Output.Add(LogType.Error, System.Console.Error);
            Output.Add(LogType.Warning, System.Console.Error);
        }

        /// <summary>
        /// The type of logging to do
        /// </summary>
        public enum LogType
        {
            Error,
            Warning,
            Parse,
            SymbolTable
        }

        /// <summary>
        /// Logs a line of text
        /// </summary>
        /// <param name="type">The type of logging to do</param>
        /// <param name="line">The line of text to be logged</param>
        protected void Log(LogType type, string line)
        {
            Output[type].WriteLine(line);
        }

        /// <summary>
        /// Logs a syntax error
        /// </summary>
        /// <param name="error">The syntax error message</param>
        protected void SyntaxError(string error)
        {
            Errors.Add(string.Format("** Syntax error:{0}", error));
        }

        /// <summary>
        /// Logs a semantic error
        /// </summary>
        /// <param name="error">The semantic error message</param>
        protected void SemanticError(string error)
        {
            Errors.Add(string.Format("** Semantic error:{0}", error));
        }

        /// <summary>
        /// Logs a "Symbol already defined" semantic error
        /// </summary>
        /// <param name="symbol">The name of the symbol</param>
        protected void SemanticErrorSymbolAlreadyDefined(string symbol)
        {
            SemanticError(string.Format("{0}:Symbol {1} already defined",
                lexer.Line, symbol));
        }

        /// <summary>
        /// Logs a warning
        /// </summary>
        /// <param name="warning">The warning messge</param>
        protected void Warning(string warning)
        {
            Warnings.Add(string.Format("*  Warning:{0}", warning));
        }

        /// <summary>
        /// The main function. Runs the parser over the stream and 
        /// returns whether or not the stream is valid.
        /// </summary>
        /// <returns>A bool indicating whether or not the stream is valid syntactically</returns>
        public bool Parse()
        {
            lookahead = lexer.GetNextToken();

            // first parse the program
            bool ok = NTF_Prog() && Match(Lexer.Token.TokenType.EndOfFile);

            // then write out the debug information
            Log(LogType.SymbolTable, Global.ToString());

            foreach (string error in Errors)
                Log(LogType.Error, error);

            foreach (string warning in Warnings)
                Log(LogType.Warning, warning);


            // and flush the streams
            foreach (TextWriter tw in Output.Values)
                tw.Flush();

            return ok;
        }

        /// <summary>w
        /// Tests whether the lookahead is in the token list
        /// </summary>
        /// <param name="tokens">The list of tokens given as either string, Lexer.Token.TokenType or Lexer.Token</param>
        /// <returns>A bool representing whether or not the lookahead is in the list</returns>
        protected bool ValidLookAhead(object[] tokens)
        {
            foreach (object o in tokens)
                if (o is string)
                {
                    if (lookahead.Value == (string)o)
                        return true;
                }
                else if (o is Lexer.Token.TokenType)
                {
                    if (lookahead.Type == (Lexer.Token.TokenType)o)
                        return true;
                }
                else if (o is Lexer.Token)
                {
                    if (lookahead.Type == ((Lexer.Token)o).Type && lookahead.Value == ((Lexer.Token)o).Value)
                        return true;
                }
                else
                    throw new InvalidDataException(
                        "Encountered an invalid token type in the first/follow token list");

            return false;
        }

        /// <summary>
        /// Skips all the errors until the next (maybe valid) token
        /// </summary>
        /// <param name="tokens">The list of "valid" tokens</param>
        /// <returns>true if there has been an error that was skipped, false otherwise</returns>
        protected bool SkipErrors(params object[] tokens)
        {
            if (ValidLookAhead(tokens))
                return false;

            SyntaxError(string.Format("{0}:unexpected token '{1}' of type '{2}'",
                lookahead.Line, lookahead.Value, lookahead.Type));

            do
            {
                if (lookahead.Type == Lexer.Token.TokenType.EndOfFile)
                    break;
                lookahead = lexer.GetNextToken();
            } while (!ValidLookAhead(tokens));

            Warning(string.Format("{0}:Resuming parsing near the token '{1}' of type '{2}'",
                lookahead.Line, lookahead.Value, lookahead.Type));

            return true;
        }

        // <prog> ::= <classdeclstar><progbody>
        protected bool NTF_Prog()
        {
            bool error = SkipErrors("class", "program", Lexer.Token.TokenType.EndOfFile);

            error |= !NTF_ClassDeclStar();
            error |= !NTF_ProgBody();

            if (!error)
                Log(LogType.Parse, "<prog> ::= <classdeclstar><progbody>");

            return !error;
        }

        // <progbody> ::= program <funcbody>;<functionstar>
        // MODIFIED
        // <progbody> ::= program <funcbody>;<definitionstar>
        protected bool NTF_ProgBody()
        {
            bool error = SkipErrors("program", Lexer.Token.TokenType.EndOfFile);

            SymbolTable.Information info;
            if ((info = CurrentScope.Find("$program", false)) != null)
            {
                SemanticErrorSymbolAlreadyDefined("$program");
                error = true;
                if (info.Properties.ContainsKey("function_symtable"))
                    if (info.Properties["function_symtable"] != null)
                        CurrentScope = info.Properties["function_symtable"] as SymbolTable;
                    else
                        info.Properties["function_symtable"] = CurrentScope = CurrentScope.CreateChild("$program");
                else
                {
                    info.Properties.Add("function_symtable", CurrentScope.CreateChild("$program"));
                    CurrentScope = info.Properties["function_symtable"] as SymbolTable;
                }
            }
            else
            {
                info = CurrentScope.Add("$program");
                info.Kind = SymbolTable.Information.EKind.Function;
                info.Properties.Add("function_symtable", CurrentScope.CreateChild("$program"));
                info.Properties.Add("function_parameters", new List<SemanticInfo.ParameterInfo>());
                info.Properties.Add("function_type", "<no type>");
                CurrentScope = info.Properties["function_symtable"] as SymbolTable;
            }

            error |= !Match("program");
            error |= !NTF_FuncBody();
            error |= !Match(Lexer.Token.TokenType.Semicolon);

            CurrentScope = CurrentScope.Parent;

            error |= !NTF_DefinitionStar();

            if (!error)
                Log(LogType.Parse, "<progbody> ::= program <funcbody> ; <definitionstar>");

            return !error;
        }

        /*
                // <functionstar> ::= e | <function><functionstar>
                protected bool NTF_FunctionStar()
                {
                    // first(<functionstar>)=first(<function>)=first(<funchead>)=first(<type>)
                    if (lookahead.Value == "int" || lookahead.Value == "float" || lookahead.Type == Lexer.Token.TokenType.Identifier)
                        if (NTF_Function() && NTF_FunctionStar())
                        {
                            Log("<functionstar> ::= <function><functionstar>");
                            return true;
                        }
                        else
                            return false;
                    // follow(<functionstar>)=}+$
                    else if (lookahead.Type == Lexer.Token.TokenType.CloseBrace || lookahead.Type == Lexer.Token.TokenType.EndOfFile)
                    {
                        Log("<functionstar> ::= e");
                        return true;
                    }
                    else
                        return false;
                }

                // <function> ::= <funchead><funcbody>;
                protected bool NTF_Function()
                {
                    if (NTF_FuncHead() && NTF_FuncBody() && Match(Lexer.Token.TokenType.Semicolon))
                    {
                        Log("<function> ::= <funchead><funcbody>;");
                        return true;
                    }
                    else
                        return false;
                }
        */

        // <funcbody> ::= {<typedeclstar><statementstar>}
        protected bool NTF_FuncBody()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.OpenBrace, Lexer.Token.TokenType.Semicolon);

            error |= !Match(Lexer.Token.TokenType.OpenBrace);
            error |= !NTF_TypeDeclStar() && NTF_StatementStar();
            error |= !Match(Lexer.Token.TokenType.CloseBrace);

            if (!error)
                Log(LogType.Parse, "<funcbody> ::= {<typedeclstar><statementstar>}");

            return !error;
        }

        // <statementstar> ::= e | <statement><statementstar>
        protected bool NTF_StatementStar()
        {
            bool error = SkipErrors("if", "for", "cin", "cout", "return", Lexer.Token.TokenType.Identifier,
                Lexer.Token.TokenType.CloseBrace);

            // first(<statement>)=first(<variable>)+if+for+cin+cout+return
            //                   =first(<idnest>)+id+if+for+cin+cout+return
            //                   =id+if+for+cin+cout+return
            if (lookahead.Value == "if" || lookahead.Value == "for" || lookahead.Value == "cin" || lookahead.Value == "cout"
                || lookahead.Value == "return" || lookahead.Type == Lexer.Token.TokenType.Identifier)
            {
                error |= !NTF_Statement();
                error |= !NTF_StatementStar();

                if (!error)
                    Log(LogType.Parse, "<statementstar> ::= <statement><statementstar>");
            }
            // follow(<statementstar>)=}
            else if (lookahead.Type == Lexer.Token.TokenType.CloseBrace)
                Log(LogType.Parse, "<statementstar> ::= e");
            else
                error = true;

            return !error;
        }

        // <statement> ::= <variable> := <expr>
        //               | if ( <expr> ) then <statblock> else <statblock> fi ;
        //               | for ( <statement> ; <expr> ; <statement> ) <statblock> ;
        //               | cin ( <variable> ) ;
        //               | cout ( <expr> ) ;
        //               | return ( <expr> ) ;
        protected bool NTF_Statement()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Identifier, "if", "for", "cin", "cout", "return",
                Lexer.Token.TokenType.CloseBrace, Lexer.Token.TokenType.Semicolon, "else", "fi");

            // first(<variable>)
            if (lookahead.Type == Lexer.Token.TokenType.Identifier)
            {
                error |= !NTF_Variable();
                error |= !Match(Lexer.Token.TokenType.Assignement);
                error |= !NTF_Expr();
                error |= !Match(Lexer.Token.TokenType.Semicolon);

                if (!error)
                    Log(LogType.Parse, "<statement> ::= <variable> := <expr>");
            }
            else if (lookahead.Value == "if")
            {
                error |= !Match("if");
                error |= !Match(Lexer.Token.TokenType.OpenBracket);
                error |= !NTF_Expr();
                error |= !Match(Lexer.Token.TokenType.CloseBracket);
                error |= !Match("then");
                error |= !NTF_StatBlock();
                error |= !Match("else");
                error |= !NTF_StatBlock();
                error |= !Match("fi");
                error |= !Match(Lexer.Token.TokenType.Semicolon);

                if (!error)
                    Log(LogType.Parse, "<statement> ::= if ( <expr> ) then <statblock> else <statblock> fi ;");
            }
            else if (lookahead.Value == "for")
            {
                error |= !Match("for");
                error |= !Match(Lexer.Token.TokenType.OpenBracket);
                error |= !NTF_Statement();
                error |= !Match(Lexer.Token.TokenType.Semicolon);
                error |= !NTF_Expr();
                error |= !Match(Lexer.Token.TokenType.Semicolon);
                error |= !NTF_Statement();
                error |= !Match(Lexer.Token.TokenType.CloseBracket);
                error |= !NTF_StatBlock();
                error |= !Match(Lexer.Token.TokenType.Semicolon);

                if (!error)
                    Log(LogType.Parse, "<statement> ::= for ( <statement> ; <expr> ; <statement> ) <statblock> ;");
            }
            else if (lookahead.Value == "cin")
            {
                error |= !Match("cin");
                error |= !Match(Lexer.Token.TokenType.OpenBracket);
                error |= !NTF_Variable();
                error |= !Match(Lexer.Token.TokenType.CloseBracket);
                error |= !Match(Lexer.Token.TokenType.Semicolon);

                if (!error)
                    Log(LogType.Parse, "<statement> ::= cin ( <variable> ) ;");
            }
            else if (lookahead.Value == "cout")
            {
                error |= !Match("cout");
                error |= !Match(Lexer.Token.TokenType.OpenBracket);
                error |= !NTF_Expr();
                error |= !Match(Lexer.Token.TokenType.CloseBracket);
                error |= !Match(Lexer.Token.TokenType.Semicolon);

                if (!error)
                    Log(LogType.Parse, "<statement> ::= cout ( <expr> ) ;");
            }
            else if (lookahead.Value == "return")
            {
                error |= !Match("return");
                error |= !Match(Lexer.Token.TokenType.OpenBracket);
                error |= !NTF_Expr();
                error |= !Match(Lexer.Token.TokenType.CloseBracket);
                error |= !Match(Lexer.Token.TokenType.Semicolon);

                if (!error)
                    Log(LogType.Parse, "<statement> ::= return ( <expr> ) ;");
            }
            else
                error = true;

            return !error;
        }

        // <statblock> ::= { <statementstar> } | <statement> | e
        protected bool NTF_StatBlock()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.OpenBrace, "if", "for", "cin", "cout", "return", Lexer.Token.TokenType.Identifier,
                "else", "fi", Lexer.Token.TokenType.Semicolon);

            if (lookahead.Type == Lexer.Token.TokenType.OpenBrace)
            {
                error |= !Match(Lexer.Token.TokenType.OpenBrace);
                error |= !NTF_StatementStar();
                error |= !Match(Lexer.Token.TokenType.CloseBrace);

                if (!error)
                    Log(LogType.Parse, "<statblock> ::= { <statementstar> }");
            }
            // first(<statementstar>)
            else if (lookahead.Value == "if" || lookahead.Value == "for" || lookahead.Value == "cin" || lookahead.Value == "cout"
                || lookahead.Value == "return" || lookahead.Type == Lexer.Token.TokenType.Identifier)
            {
                error |= !NTF_Statement();

                if (!error)
                    Log(LogType.Parse, "<statblock> ::= <statement>");
            }
            // follow(<statblock>)=else+fi+;
            else if (lookahead.Value == "else" || lookahead.Value == "fi" || lookahead.Type == Lexer.Token.TokenType.Semicolon)
                Log(LogType.Parse, "<statblock> ::= e");
            else
                error = true;

            return !error;
        }

        // <expr> ::= <arithexpr><expr2>
        protected bool NTF_Expr()
        {
            bool error = SkipErrors("+", "-", Lexer.Token.TokenType.Identifier, Lexer.Token.TokenType.Number,
                Lexer.Token.TokenType.OpenBracket, Lexer.Token.TokenType.Not,
                Lexer.Token.TokenType.Semicolon, Lexer.Token.TokenType.CloseBracket);

            error |= !NTF_ArithExpr();
            error |= !NTF_Expr2();

            if (!error)
                Log(LogType.Parse, "<expr> ::= <arithexpr> <expr2>");

            return !error;
        }

        // <arithexpr> ::= <term> <arithexpr2> | <sign> <term> <arithexpr2>
        protected bool NTF_ArithExpr()
        {
            bool error = SkipErrors("+", "-", Lexer.Token.TokenType.Identifier, Lexer.Token.TokenType.Number,
                Lexer.Token.TokenType.OpenBracket, Lexer.Token.TokenType.Not,
                Lexer.Token.TokenType.Comparison, Lexer.Token.TokenType.Additive, Lexer.Token.TokenType.CloseSquareBracket,
                Lexer.Token.TokenType.Comma, Lexer.Token.TokenType.CloseBracket, Lexer.Token.TokenType.Semicolon);

            // first(<term>)=first(<variable>)+num+(+!
            if (lookahead.Type == Lexer.Token.TokenType.Identifier || lookahead.Type == Lexer.Token.TokenType.Number
                || lookahead.Type == Lexer.Token.TokenType.OpenBracket || lookahead.Type == Lexer.Token.TokenType.Not)
            {
                error |= !NTF_Term();
                error |= !NTF_ArithExpr2();

                if (!error)
                    Log(LogType.Parse, "<arithexpr> ::= <term> <arithexpr2>");
            }
            else if (lookahead.Value == "+" || lookahead.Value == "-")
            {
                error |= !NTF_Sign();
                error |= !NTF_Term();
                error |= !NTF_ArithExpr2();

                if (!error)
                    Log(LogType.Parse, "<arithexpr> ::= <sign> <term> <arithexpr2>");
            }
            else
                error = true;

            return !error;
        }

        // <sign> ::= + | -
        protected bool NTF_Sign()
        {
            bool error = SkipErrors("+", "-",
                Lexer.Token.TokenType.Identifier, Lexer.Token.TokenType.Number, Lexer.Token.TokenType.OpenBracket,
                Lexer.Token.TokenType.Not);

            if (lookahead.Value == "+")
            {
                error |= !Match("+");

                if (!error)
                    Log(LogType.Parse, "<sign> ::= +");
            }
            else
            {
                error |= !Match("-");

                if (!error)
                    Log(LogType.Parse, "<sign> ::= -");
            }

            return false;
        }

        // <arithexpr2> ::= e | addop <term><arithexpr2>
        protected bool NTF_ArithExpr2()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Additive,
                Lexer.Token.TokenType.Semicolon, Lexer.Token.TokenType.CloseBracket, Lexer.Token.TokenType.Comparison,
                Lexer.Token.TokenType.CloseSquareBracket, Lexer.Token.TokenType.Comma);

            // first(<arithexpr2>)=addop
            if (lookahead.Type == Lexer.Token.TokenType.Additive)
            {
                error |= !Match(Lexer.Token.TokenType.Additive);
                error |= !NTF_Term();
                error |= !NTF_ArithExpr2();

                if (!error)
                    Log(LogType.Parse, "<arithexpr2> ::= addop <term> <arithexpr2>");
            }
            // follow(<arithexpr2>)=follow(<arithexpr>)=follow(<expr>)+relop+addop+]+,+follow(<aparams>)
            //                     =;+)+relop+addop+]+,
            else if (lookahead.Type == Lexer.Token.TokenType.Semicolon || lookahead.Type == Lexer.Token.TokenType.CloseBracket
                || lookahead.Type == Lexer.Token.TokenType.Additive || lookahead.Type == Lexer.Token.TokenType.Comparison
                || lookahead.Type == Lexer.Token.TokenType.CloseSquareBracket || lookahead.Type == Lexer.Token.TokenType.Comma)
                Log(LogType.Parse, "<arithexpr2> ::= e");
            else
                error = true;

            return !error;
        }

        // <term> ::= <factor> <term2>
        protected bool NTF_Term()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Identifier, Lexer.Token.TokenType.OpenBracket, Lexer.Token.TokenType.Not,
                Lexer.Token.TokenType.Number,
                Lexer.Token.TokenType.Multiplicative, Lexer.Token.TokenType.Comma, Lexer.Token.TokenType.CloseBracket,
                Lexer.Token.TokenType.Comparison, Lexer.Token.TokenType.Additive, Lexer.Token.TokenType.Semicolon);

            error |= !NTF_Factor();
            error |= !NTF_Term2();

            if (!error)
                Log(LogType.Parse, "<term> ::= <factor> <term2>");

            return !error;
        }

        // <term2> ::= e | multop <factor> <term2>
        protected bool NTF_Term2()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Multiplicative,
                Lexer.Token.TokenType.Semicolon, Lexer.Token.TokenType.CloseBracket, Lexer.Token.TokenType.Additive,
                Lexer.Token.TokenType.Comparison, Lexer.Token.TokenType.CloseSquareBracket, Lexer.Token.TokenType.Comma);

            if (lookahead.Type == Lexer.Token.TokenType.Multiplicative)
            {
                error |= !Match(Lexer.Token.TokenType.Multiplicative);
                error |= !NTF_Factor();
                error |= !NTF_Term2();

                if (!error)
                    Log(LogType.Parse, "<term2> ::= multop <factor> <term2>");
            }
            // follow(<term2>)=follow(<term>)=follow(<arithexpr>)=;+)+relop+addop+]+,
            else if (lookahead.Type == Lexer.Token.TokenType.Semicolon || lookahead.Type == Lexer.Token.TokenType.CloseBracket
                || lookahead.Type == Lexer.Token.TokenType.Additive || lookahead.Type == Lexer.Token.TokenType.Comparison
                || lookahead.Type == Lexer.Token.TokenType.CloseSquareBracket || lookahead.Type == Lexer.Token.TokenType.Comma)
                Log(LogType.Parse, "<term2> ::= e");
            else
                error = true;

            return !error;
        }

        // <factor> ::= <idnest> <factor2>
        //            | num
        //            | ( <expr> )
        //            | ! <factor>
        protected bool NTF_Factor()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Identifier, Lexer.Token.TokenType.Number, Lexer.Token.TokenType.OpenBracket,
                Lexer.Token.TokenType.Not, Lexer.Token.TokenType.Multiplicative, Lexer.Token.TokenType.Comparison,
                Lexer.Token.TokenType.Additive, Lexer.Token.TokenType.Comma, Lexer.Token.TokenType.CloseBracket,
                Lexer.Token.TokenType.Semicolon);

            // first(<idneststar>)=id
            if (lookahead.Type == Lexer.Token.TokenType.Identifier)
            {
                error |= !NTF_IdNest();
                error |= !NTF_Factor2();

                if (!error)
                    Log(LogType.Parse, "<factor> ::= <idneststar> id <factor2>");
            }
            else if (lookahead.Type == Lexer.Token.TokenType.Number)
            {
                error |= !Match(Lexer.Token.TokenType.Number);

                if (!error)
                    Log(LogType.Parse, "<factor> ::= num");
            }
            else if (lookahead.Type == Lexer.Token.TokenType.OpenBracket)
            {
                error |= !Match(Lexer.Token.TokenType.OpenBracket);
                error |= !NTF_Expr();
                error |= !Match(Lexer.Token.TokenType.CloseBracket);

                if (!error)
                    Log(LogType.Parse, "<factor> ::= ( <expr> )");
            }
            else if (lookahead.Type == Lexer.Token.TokenType.Not)
            {
                error |= !Match(Lexer.Token.TokenType.Not);
                error |= !NTF_Factor();

                if (!error)
                    Log(LogType.Parse, "<factor> ::= ! <factor>");
            }
            else
                error = true;

            return !error;
        }

        // <factor2> ::= <indicestar>
        //             | ( <aparams> )
        protected bool NTF_Factor2()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.OpenSquareBracket, Lexer.Token.TokenType.Multiplicative,
                Lexer.Token.TokenType.Additive, Lexer.Token.TokenType.Comma, Lexer.Token.TokenType.CloseBracket,
                Lexer.Token.TokenType.Comparison, Lexer.Token.TokenType.Semicolon, Lexer.Token.TokenType.OpenBracket);

            // first(<factor2>.1)=first(<indicestar>)+follow(<factor2>)
            // =[+multop+addop+,+)+;
            if (lookahead.Type == Lexer.Token.TokenType.OpenSquareBracket || lookahead.Type == Lexer.Token.TokenType.Multiplicative
                || lookahead.Type == Lexer.Token.TokenType.Additive || lookahead.Type == Lexer.Token.TokenType.Comma
                || lookahead.Type == Lexer.Token.TokenType.CloseBracket || lookahead.Type == Lexer.Token.TokenType.Comparison
                || lookahead.Type == Lexer.Token.TokenType.Semicolon)
            {
                error |= !NTF_IndiceStar();

                if (!error)
                    Log(LogType.Parse, "<factor2> ::= <indicestar>");
            }
            else if (lookahead.Type == Lexer.Token.TokenType.OpenBracket)
            {
                error |= !Match(Lexer.Token.TokenType.OpenBracket);
                error |= !NTF_AParams();
                error |= !Match(Lexer.Token.TokenType.CloseBracket);

                if (!error)
                    Log(LogType.Parse, "<factor2> ::= ( <aparams> )");
            }

            return !error;
        }

        // <aparams> ::= <arithexpr> <aparamstailstar> | e
        protected bool NTF_AParams()
        {
            bool error = SkipErrors("+", "-", Lexer.Token.TokenType.Identifier, Lexer.Token.TokenType.Number,
                Lexer.Token.TokenType.OpenBracket, Lexer.Token.TokenType.Not, Lexer.Token.TokenType.CloseBracket);

            // first(<arithexpr>)=++-+first(<term>)=++-+id+num+(+!
            if (lookahead.Value == "+" || lookahead.Value == "-" || lookahead.Type == Lexer.Token.TokenType.Identifier
                || lookahead.Type == Lexer.Token.TokenType.Number || lookahead.Type == Lexer.Token.TokenType.OpenBracket
                || lookahead.Type == Lexer.Token.TokenType.Not)
            {
                error |= !NTF_ArithExpr();
                error |= !NTF_AParamsTailStar();

                if (!error)
                    Log(LogType.Parse, "<aparams> ::= <arithexpr> <aparamstail>");
            }
            // follow = )
            else if (lookahead.Type == Lexer.Token.TokenType.CloseBracket)
                Log(LogType.Parse, "<aparams> ::= e");
            else
                error = true;

            return !error;
        }

        // <aparamstailstar> ::= e | <aparamstail> <aparamstailstar>
        protected bool NTF_AParamsTailStar()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Comma, Lexer.Token.TokenType.CloseBracket);

            if (lookahead.Type == Lexer.Token.TokenType.Comma)
            {
                error |= !NTF_AParamsTail();
                error |= !NTF_AParamsTailStar();

                if (!error) 
                    Log(LogType.Parse, "<aparamstailstar> ::= <apramstail> <aparamstailstar>");
            }
            // follow=)
            else if (lookahead.Type == Lexer.Token.TokenType.CloseBracket)
                Log(LogType.Parse, "<aparamstailstar> ::= e");
            else
                error = true;

            return !error;
        }

        // <apramstail> ::= , <arithexpr> | e
        protected bool NTF_AParamsTail()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Comma, Lexer.Token.TokenType.CloseBracket);

            if (lookahead.Type == Lexer.Token.TokenType.Comma)
            {
                error |= !Match(Lexer.Token.TokenType.Comma);
                error |= !NTF_ArithExpr();

                if (!error)
                    Log(LogType.Parse, "<aparamstail> ::= , <arithexpr>");
            }
            else if (lookahead.Type == Lexer.Token.TokenType.CloseBracket)
                Log(LogType.Parse, "<araparmstail> ::= e");
            else
                error = true;

            return !error;
        }

        // <indicestar> ::= e | <indice> <indicestar>
        protected bool NTF_IndiceStar()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.OpenSquareBracket,
                Lexer.Token.TokenType.Dot, Lexer.Token.TokenType.Assignement, Lexer.Token.TokenType.CloseBracket,
                Lexer.Token.TokenType.Multiplicative, Lexer.Token.TokenType.Additive, Lexer.Token.TokenType.Comma,
                Lexer.Token.TokenType.Comparison, Lexer.Token.TokenType.Semicolon, Lexer.Token.TokenType.OpenBracket,
                Lexer.Token.TokenType.Identifier);

            if (lookahead.Type == Lexer.Token.TokenType.OpenSquareBracket)
            {
                error |= !NTF_Indice();
                error |= !NTF_IndiceStar();

                if (!error)
                    Log(LogType.Parse, "<indicestar> ::= <indice> <indicestar>");
            }
            // follow(indicestar)=.+:=+)+multop+addop+,+relop+;+(
            else if (lookahead.Type == Lexer.Token.TokenType.Dot || lookahead.Type == Lexer.Token.TokenType.Assignement
                || lookahead.Type == Lexer.Token.TokenType.CloseBracket || lookahead.Type == Lexer.Token.TokenType.Multiplicative
                || lookahead.Type == Lexer.Token.TokenType.Additive || lookahead.Type == Lexer.Token.TokenType.Comma
                || lookahead.Type == Lexer.Token.TokenType.Comparison || lookahead.Type == Lexer.Token.TokenType.Semicolon
                || lookahead.Type == Lexer.Token.TokenType.OpenBracket || lookahead.Type == Lexer.Token.TokenType.Identifier)
                Log(LogType.Parse, "<indicestar> ::= e");
            else
                error = true;

            return !error;
        }

        // <indice> ::= [ <arithexpr> ] | e
        protected bool NTF_Indice()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.OpenSquareBracket,
                Lexer.Token.TokenType.Identifier, Lexer.Token.TokenType.Dot, Lexer.Token.TokenType.Assignement,
                Lexer.Token.TokenType.CloseBracket, Lexer.Token.TokenType.Multiplicative, Lexer.Token.TokenType.Additive,
                Lexer.Token.TokenType.Comma);

            if (lookahead.Type == Lexer.Token.TokenType.OpenSquareBracket)
            {
                error |= !Match(Lexer.Token.TokenType.OpenSquareBracket);
                error |= !NTF_ArithExpr();
                error |= !Match(Lexer.Token.TokenType.CloseSquareBracket);

                if (!error)
                    Log(LogType.Parse, "<indice> ::= [ <arithexpr> ]");
            }
            // follow=.+follow(variable)=.+:=+)+multop+addop+,+id
            else if (lookahead.Type == Lexer.Token.TokenType.Identifier || lookahead.Type == Lexer.Token.TokenType.Dot
                || lookahead.Type == Lexer.Token.TokenType.Assignement || lookahead.Type == Lexer.Token.TokenType.CloseBracket
                || lookahead.Type == Lexer.Token.TokenType.Multiplicative || lookahead.Type == Lexer.Token.TokenType.Additive
                || lookahead.Type == Lexer.Token.TokenType.Comma)
                Log(LogType.Parse, "<indice> ::= e");
            else
                error = true;

            return !error;
        }

        // <idnest> ::= id <idnest2>
        // made it to read the name of the method/class im calling too
        // MODIFIED 
        // <idnest> ::= id <indicestar> <idnest2>
        protected bool NTF_IdNest()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Identifier,
                Lexer.Token.TokenType.OpenSquareBracket, Lexer.Token.TokenType.OpenBracket, Lexer.Token.TokenType.Dot,
                Lexer.Token.TokenType.Semicolon, Lexer.Token.TokenType.CloseBracket, Lexer.Token.TokenType.Comparison,
                Lexer.Token.TokenType.Additive, Lexer.Token.TokenType.CloseSquareBracket, Lexer.Token.TokenType.Comma,
                Lexer.Token.TokenType.Assignement, Lexer.Token.TokenType.Multiplicative);

            error |= !Match(Lexer.Token.TokenType.Identifier);
            error |= !NTF_IndiceStar();
            error |= !NTF_IdNest2();

            if (!error)
                Log(LogType.Parse, "<idnest> ::= id <indicestar> <idnest2>");

            return !error;
        }

        // <idnest2> ::= <indicestar> . <idnest> | e
        // MODIFIED
        // <idnest2> ::= . <idnest> | e
        protected bool NTF_IdNest2()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Dot,
                Lexer.Token.TokenType.OpenSquareBracket, Lexer.Token.TokenType.OpenBracket, Lexer.Token.TokenType.Dot,
                Lexer.Token.TokenType.Semicolon, Lexer.Token.TokenType.CloseBracket, Lexer.Token.TokenType.Comparison,
                Lexer.Token.TokenType.Additive, Lexer.Token.TokenType.CloseSquareBracket, Lexer.Token.TokenType.Comma,
                Lexer.Token.TokenType.Assignement, Lexer.Token.TokenType.Multiplicative);

            // first(<idnest2>.1)=.
            if (lookahead.Type == Lexer.Token.TokenType.Dot)
            {
                error |= !Match(Lexer.Token.TokenType.Dot);
                error |= !NTF_IdNest();

                if (!error)
                    Log(LogType.Parse, "<idnest2> ::= . <idnest>");
            }
            // follow(idnest2)=follow(idnest)=[+follow(variable)+(=[+(+:=+)+follow(factor)
            //                =[+(+:=+)+follow(term)=[+(+:=+)+addop+multop+follow(arithexpr)
            //                =;+)+relop+addop+]+,+[+(+:=+multop
            else if (lookahead.Type == Lexer.Token.TokenType.Semicolon || lookahead.Type == Lexer.Token.TokenType.CloseBracket ||
                lookahead.Type == Lexer.Token.TokenType.Comparison || lookahead.Type == Lexer.Token.TokenType.Additive ||
                lookahead.Type == Lexer.Token.TokenType.CloseSquareBracket || lookahead.Type == Lexer.Token.TokenType.Comma ||
                lookahead.Type == Lexer.Token.TokenType.OpenSquareBracket || lookahead.Type == Lexer.Token.TokenType.OpenBracket ||
                lookahead.Type == Lexer.Token.TokenType.OpenSquareBracket || lookahead.Type == Lexer.Token.TokenType.Assignement ||
                lookahead.Type == Lexer.Token.TokenType.Multiplicative)
                Log(LogType.Parse, "<idnest2> ::= e");
            else
                error = true;

            return !error;
        }

        // <expr2> ::= e | relop <arithexpr>
        protected bool NTF_Expr2()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Comparison,
                Lexer.Token.TokenType.Semicolon, Lexer.Token.TokenType.CloseBracket);

            // first(<expr2>)=relop
            if (lookahead.Type == Lexer.Token.TokenType.Comparison)
            {
                error |= !Match(Lexer.Token.TokenType.Comparison);
                error |= !NTF_ArithExpr();

                if (!error)
                    Log(LogType.Parse, "<expr2> ::= relop <arithexpr>");
            }
            // follow(<expr2>)=follow(<expr>)=;+)
            else if (lookahead.Type == Lexer.Token.TokenType.Semicolon || lookahead.Type == Lexer.Token.TokenType.CloseBracket)
                Log(LogType.Parse, "<expr2> ::= e");
            else
                error = true;

            return !error;
        }

        // <variable> ::= <idnest> <indicestar>
        protected bool NTF_Variable()
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Identifier,
                Lexer.Token.TokenType.Assignement, Lexer.Token.TokenType.Multiplicative, Lexer.Token.TokenType.Additive,
                Lexer.Token.TokenType.Comparison, Lexer.Token.TokenType.Comma, Lexer.Token.TokenType.CloseBracket,
                Lexer.Token.TokenType.Semicolon);

            error |= !NTF_IdNest();
            error |= !NTF_IndiceStar();

            if (!error)
                Log(LogType.Parse, "<variable> ::= <idnest> <indicestar>");

            return !error;
        }

        /*
        // <funchead> ::= <type> id ( <fparams> )
        protected bool NTF_FuncHead()
        {
            if (NTF_Type() && Match(Lexer.Token.TokenType.Identifier) && Match(Lexer.Token.TokenType.OpenBracket)
                && NTF_FParams() && Match(Lexer.Token.TokenType.CloseBracket))
            {
                Log("<funchead> ::= <type> id ( <fparams> )");
                return true;
            }
            else
                return false;
        }
        */

        // <fparams> ::= <type> id <arraystar> <fparamstailstar> | e
        protected bool NTF_FParams(SemanticInfo si)
        {
            bool error = SkipErrors("int", "float", Lexer.Token.TokenType.Identifier,
                Lexer.Token.TokenType.CloseBracket);

            if (lookahead.Value == "int" || lookahead.Value == "float" || lookahead.Type == Lexer.Token.TokenType.Identifier)
            {
                SemanticInfo paramsi = new SemanticInfo();

                error |= !NTF_Type(paramsi);
                paramsi.Name = lookahead.Value;
                error |= !Match(Lexer.Token.TokenType.Identifier);
                error |= !NTF_ArrayStar(paramsi);

                si.Parameters.Add(new SemanticInfo.ParameterInfo
                {
                    Name=paramsi.Name,
                    Type = paramsi.Type,
                    ArrayIndices = paramsi.ArrayIndices
                });

                error |= !NTF_FParamsTailStar(si);

                if (!error)
                    Log(LogType.Parse, "<fparams> ::= <type> id <arraystar> <fparamstailstar>");
            }
            else if (lookahead.Type == Lexer.Token.TokenType.CloseBracket)
                Log(LogType.Parse, "fparams> ::= e");
            else
                error = true;

            return !error;
        }

        // <fparamstailstar> ::= e | <fparamstail><fparamstairlstar>
        protected bool NTF_FParamsTailStar(SemanticInfo si)
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Comma,
                Lexer.Token.TokenType.CloseBracket);

            if (lookahead.Type == Lexer.Token.TokenType.Comma)
            {
                error |= !NTF_FParamsTail(si);
                error |= !NTF_FParamsTailStar(si);

                if (!error)
                    Log(LogType.Parse, "<fparamstailstar> ::= <fparamstail> <fparamstailstar>");
            }
            else if (lookahead.Type == Lexer.Token.TokenType.CloseBracket)
                Log(LogType.Parse, "<fparamstailstar> ::= e");
            else
                error = true;

            return !error;
        }

        // <fparamstail> ::= e | , <type> id <arraystar>
        protected bool NTF_FParamsTail(SemanticInfo si)
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Comma,
                Lexer.Token.TokenType.CloseBracket);

            if (lookahead.Type == Lexer.Token.TokenType.Comma)
            {
                SemanticInfo paramsi = new SemanticInfo();

                error |= !Match(Lexer.Token.TokenType.Comma);
                error |= !NTF_Type(paramsi);
                paramsi.Name = lookahead.Value;
                error |= !Match(Lexer.Token.TokenType.Identifier);
                error |= !NTF_ArrayStar(paramsi);

                si.Parameters.Add(new SemanticInfo.ParameterInfo
                {
                    Name=paramsi.Name,
                    Type = paramsi.Type,
                    ArrayIndices = paramsi.ArrayIndices
                });

                if (!error)
                    Log(LogType.Parse, "<fparamstail> ::= , <type> id <arraystar>");
            }
            else if (lookahead.Type == Lexer.Token.TokenType.CloseBracket)
                Log(LogType.Parse, "<fparamstail> ::= e");
            else
                error = true;

            return !error;
        }

        // <arraystar> ::= e | <array> <arraystar>
        protected bool NTF_ArrayStar(SemanticInfo si)
        {
            bool error = SkipErrors(Lexer.Token.TokenType.OpenSquareBracket,
                Lexer.Token.TokenType.Semicolon, Lexer.Token.TokenType.Comma, Lexer.Token.TokenType.CloseBracket);

            if (lookahead.Type == Lexer.Token.TokenType.OpenSquareBracket)
            {
                error |= !NTF_Array(si);
                error |= !NTF_ArrayStar(si);

                if (!error)
                    Log(LogType.Parse, "<arraystar> ::= <array> <arraystar>");
            }
            // follow=;+,+)
            else
                if (lookahead.Type == Lexer.Token.TokenType.Semicolon || lookahead.Type == Lexer.Token.TokenType.Comma
                    || lookahead.Type == Lexer.Token.TokenType.CloseBracket)
                    Log(LogType.Parse, "<arraystar> ::= e");
                else
                    error = true;

            return !error;
        }

        // <array> ::= [ <int> ] | e
        protected bool NTF_Array(SemanticInfo si)
        {
            bool error = SkipErrors(Lexer.Token.TokenType.OpenSquareBracket,
                Lexer.Token.TokenType.Comma, Lexer.Token.TokenType.CloseBracket, Lexer.Token.TokenType.Semicolon);

            if (lookahead.Type == Lexer.Token.TokenType.OpenSquareBracket)
            {
                SemanticInfo inti = new SemanticInfo();

                error |= !Match(Lexer.Token.TokenType.OpenSquareBracket);
                error |= !NTF_Int(inti);
                error |= !Match(Lexer.Token.TokenType.CloseSquareBracket);

                si.ArrayIndices.Add(inti.Name);

                if (!error)
                    Log(LogType.Parse, "<array> ::= [ <int> ]");
            }
            // follow=,+)+;
            else if (lookahead.Type == Lexer.Token.TokenType.Comma || lookahead.Type == Lexer.Token.TokenType.CloseBracket
                || lookahead.Type == Lexer.Token.TokenType.Semicolon)
                Log(LogType.Parse, "<array> ::= e");
            else
                error = true;

            return !error;
        }

        protected bool NTF_Int(SemanticInfo si)
        {
            bool error = SkipErrors(Lexer.Token.TokenType.Number,
                Lexer.Token.TokenType.CloseSquareBracket);

            if (lookahead.Type == Lexer.Token.TokenType.Number && lookahead.Value.IndexOf(".") < 0)
            {
                si.Name = lookahead.Value;
                error |= !Match(Lexer.Token.TokenType.Number);

                if (!error)
                    Log(LogType.Parse, "<int> ::= int");
            }
            else
                error = true;

            return !error;
        }

        // <typedeclstar> ::= e | <typedecl><typedeclstar>
        protected bool NTF_TypeDeclStar()
        {
            bool error = SkipErrors("int", "float", Lexer.Token.TokenType.Identifier,
                "if", "for", "cin", "cout", "return", Lexer.Token.TokenType.CloseBrace);

            // first(<typedecl>)
            if (lookahead.Type == Lexer.Token.TokenType.Identifier || lookahead.Value == "int" || lookahead.Value == "float")
            {
                // if the next token after the lookahead isnt id, skip to ::=e
                if (lexer.PeekNextToken().Type != Lexer.Token.TokenType.Identifier)
                    Log(LogType.Parse, "<typedeclstar> ::= e (FORCED)");
                else
                {
                    error |= !NTF_TypeDecl();
                    error |= !NTF_TypeDeclStar();

                    if (!error)
                        Log(LogType.Parse, "<typedeclstar> ::= <typedecl><typedeclstar>");
                }
            }
            // follow(<typedeclstar>)=first(<statementstar)+}+first(functionstar)
            //                       =first(<statement>)+}+first(function)
            //                       =if|for|cin|cout|return|first(<variable>)|}|first(funchead)
            //                       =if+for+cin+cout+return+id+}+int+float
            else if (lookahead.Value == "if" || lookahead.Value == "for" || lookahead.Value == "cin"
                || lookahead.Value == "cout" || lookahead.Value == "return" || lookahead.Type == Lexer.Token.TokenType.CloseBrace
                || lookahead.Type == Lexer.Token.TokenType.Identifier || lookahead.Value == "int"
                || lookahead.Value == "float")
                Log(LogType.Parse, "<typedeclstar> ::= e");
            else
                error = true;

            return !error;
        }

        // <typedecl> ::= <type> id <arraystar>;
        protected bool NTF_TypeDecl()
        {
            bool error = SkipErrors("int", "float", Lexer.Token.TokenType.Identifier,
                "if", "cin", "cout", "return", "for", Lexer.Token.TokenType.CloseBrace);

            SemanticInfo si = new SemanticInfo();

            error |= !NTF_Type(si);
            si.Name = lookahead.Value;
            error |= !Match(Lexer.Token.TokenType.Identifier);
            error |= !NTF_ArrayStar(si);
            error |= !Match(Lexer.Token.TokenType.Semicolon);

            SymbolTable.Information info;
            if ((info = CurrentScope.Find(si.Name, false)) != null)
                SemanticErrorSymbolAlreadyDefined(si.Name);
            else
            {
                info = CurrentScope.Add(si.Name);
                info.Kind = SymbolTable.Information.EKind.Variable;
                info.Properties.Add("variable_type", si.Type);
                info.Properties.Add("variable_arrayindices", si.ArrayIndices.ToArray());
            }

            if (!error)
                Log(LogType.Parse, "<typedecl> ::= <type> id <arraystar>;");

            return !error;
        }

        // <type> ::= int | float | id
        protected bool NTF_Type(SemanticInfo si)
        {
            bool error = SkipErrors("int", "float", Lexer.Token.TokenType.Identifier);

            if (lookahead.Value == "int")
            {
                si.Type = "int";
                error |= !Match("int");

                if (!error)
                    Log(LogType.Parse, "<type> ::= int");
            }
            else if (lookahead.Value == "float")
            {
                si.Type = "float";
                error |= !Match("float");

                if (!error)
                    Log(LogType.Parse, "<type> ::= float");
            }
            else if (lookahead.Type == Lexer.Token.TokenType.Identifier)
            {
                si.Type = lookahead.Value;
                error |= !Match(Lexer.Token.TokenType.Identifier);

                if (!error)
                    Log(LogType.Parse, "<type> ::= id");
            }

            return !error;
        }

        // <classdeclstar> ::= e | <classdecl><classdeclstar>
        protected bool NTF_ClassDeclStar()
        {
            bool error = SkipErrors("class", "program");

            if (lookahead.Value == "class")                                    // first(<classdecl>)
            {
                error |= !NTF_ClassDecl();
                error |= !NTF_ClassDeclStar();

                if (!error)
                    Log(LogType.Parse, "<classdeclstar> ::= <classdecl><classdeclstar>");
            }
            else
                if (lookahead.Value == "program")                              // follow(<classdecl>)
                    Log(LogType.Parse, "<classdeclstar> ::= e");
                else
                    error = true;

            return !error;
        }

        // <classdecl> ::= class id { <typedeclstar> <functionstar> } ;
        // MODIFIED
        // <classdecl> ::= class id { <definitionstar> } ;
        protected bool NTF_ClassDecl()
        {
            /*
                        if (Match("class") && Match(Lexer.Token.TokenType.Identifier) && Match(Lexer.Token.TokenType.OpenBrace)
                            && NTF_TypeDeclStar() && NTF_FunctionStar() && Match(Lexer.Token.TokenType.CloseBrace)
                            && Match(Lexer.Token.TokenType.Semicolon))
                        {
                            Log("<classdecl> ::= class id {<typedeclstar><functionstar>};");
                            return true;
                        }
                        else
                            return false;
            */
            bool error = SkipErrors("class", "program");

            error |= !Match("class");

            SymbolTable child;
            SymbolTable.Information info;
            if ((info = CurrentScope.Find(lookahead.Value, false)) != null)
            {
                SemanticErrorSymbolAlreadyDefined(lookahead.Value);
                error = true;
                if (info.Properties.ContainsKey("class_symtable"))
                    if (info.Properties["class_symtable"] != null)
                        child = info.Properties["class_symtable"] as SymbolTable;
                    else
                        info.Properties["class_symtable"] = child = CurrentScope.CreateChild(lookahead.Value);
                else
                {
                    info.Properties.Add("class_symtable", CurrentScope.CreateChild(lookahead.Value));
                    child = info.Properties["class_symtable"] as SymbolTable;
                }
            }
            else
            {
                info = CurrentScope.Add(lookahead.Value);
                child = CurrentScope.CreateChild(lookahead.Value);

                info.Kind = SymbolTable.Information.EKind.Class;
                info.Properties.Add("class_symtable", child);
            }

            CurrentScope = child;

            error |= !Match(Lexer.Token.TokenType.Identifier);
            error |= !Match(Lexer.Token.TokenType.OpenBrace);
            error |= !NTF_DefinitionStar();
            error |= !Match(Lexer.Token.TokenType.CloseBrace);
            error |= !Match(Lexer.Token.TokenType.Semicolon);

            CurrentScope = CurrentScope.Parent;

            if (!error)
                Log(LogType.Parse, "<classdecl> := class id { <definitionstar> } ;");

            return !error;
        }

        // <definitionstar> ::= e | <definition> <definitionstar>
        protected bool NTF_DefinitionStar()
        {
            bool error = SkipErrors("int", "float", Lexer.Token.TokenType.Identifier, Lexer.Token.TokenType.CloseBrace,
                Lexer.Token.TokenType.EndOfFile);

            if (lookahead.Value == "int" || lookahead.Value == "float" || lookahead.Type == Lexer.Token.TokenType.Identifier)
            {
                error |= !NTF_Definition();
                error |= !NTF_DefinitionStar();

                if (!error)
                    Log(LogType.Parse, "<definitionstar> ::= <definition> <definitionstar>");
            }
            // follow=}+$
            else if (lookahead.Type == Lexer.Token.TokenType.EndOfFile || lookahead.Type == Lexer.Token.TokenType.CloseBrace)
                Log(LogType.Parse, "<definitionstar> ::= e");
            else
                error = true;

            return !error;
        }

        // <definition> ::= <type> id <definition2>
        protected bool NTF_Definition()
        {
            bool error = SkipErrors("int", "float", Lexer.Token.TokenType.Identifier, Lexer.Token.TokenType.CloseBrace,
                Lexer.Token.TokenType.EndOfFile);
            SemanticInfo si = new SemanticInfo();

            error |= !NTF_Type(si);

            si.Name = lookahead.Value;
            error |= !Match(Lexer.Token.TokenType.Identifier);

            error |= !NTF_Definition2(si);

            if (!error)
                Log(LogType.Parse, "<definition> ::= <type> id <definition2>");

            return !error;
        }

        // <definition2> ::= ( <fparams> ) <funcbody> ;
        //                 | <arraystar> ;
        protected bool NTF_Definition2(SemanticInfo si)
        {
            bool error = SkipErrors(Lexer.Token.TokenType.OpenBracket, Lexer.Token.TokenType.OpenSquareBracket,
                Lexer.Token.TokenType.Semicolon,
                Lexer.Token.TokenType.CloseBrace, Lexer.Token.TokenType.EndOfFile);

            if (lookahead.Type == Lexer.Token.TokenType.OpenBracket)
            {
                error |= !Match(Lexer.Token.TokenType.OpenBracket);
                error |= !NTF_FParams(si);
                error |= !Match(Lexer.Token.TokenType.CloseBracket);

                SymbolTable.Information info;
                if ((info = CurrentScope.Find(si.Name, false)) != null)
                {
                    SemanticErrorSymbolAlreadyDefined(si.Name);
                    error = true;

                    if (info.Properties.ContainsKey("function_symtable"))
                        if (info.Properties["function_symtable"] != null)
                            CurrentScope = info.Properties["function_symtable"] as SymbolTable;
                        else
                            info.Properties["function_symtable"] = CurrentScope = CurrentScope.CreateChild(si.Name);
                    else
                    {
                        info.Properties.Add(si.Name, CurrentScope.CreateChild(si.Name));
                        CurrentScope = info.Properties[si.Name] as SymbolTable;
                    }
                }
                else
                {
                    info = CurrentScope.Add(si.Name);
                    info.Kind = SymbolTable.Information.EKind.Function;
                    info.Properties.Add("function_parameters", si.Parameters);
                    info.Properties.Add("function_type", si.Type);
                    info.Properties.Add("function_symtable", CurrentScope.CreateChild(si.Name));
                    CurrentScope = info.Properties["function_symtable"] as SymbolTable;
                }

                error |= !NTF_FuncBody();
                error |= !Match(Lexer.Token.TokenType.Semicolon);

                CurrentScope = CurrentScope.Parent;

                if (!error)
                    Log(LogType.Parse, "<definition2> ::= ( <fparams> ) <funcbody> ;");
            }
            else if (lookahead.Type == Lexer.Token.TokenType.OpenSquareBracket || lookahead.Type == Lexer.Token.TokenType.Semicolon)
            {
                error |= !NTF_ArrayStar(si);
                error |= !Match(Lexer.Token.TokenType.Semicolon);

                SymbolTable.Information info;
                if ((info = CurrentScope.Find(si.Name, false)) != null)
                {
                    SemanticErrorSymbolAlreadyDefined(si.Name);
                    error = true;
                }
                else
                {
                    info = CurrentScope.Add(si.Name);
                    info.Kind = SymbolTable.Information.EKind.Variable;
                    info.Properties["variable_arrayindices"] = new string[si.ArrayIndices.Count];
                    for (int i = 0; i < si.ArrayIndices.Count; ++i)
                        (info.Properties["variable_arrayindices"] as string[])[i] = si.ArrayIndices[i];
                    info.Properties["variable_type"] = si.Type;
                }

                if (!error)
                    Log(LogType.Parse, "<definition2> ::= <arraystar> ;");
            }

            return !error;
        }

        /// <summary>
        /// Tries to match a token from a type
        /// </summary>
        /// <param name="type">The type of the token to match against</param>
        /// <returns></returns>
        protected bool Match(Lexer.Token.TokenType type)
        {
            return Match(null, type);
        }

        /// <summary>
        /// Tries to match a token from a value
        /// </summary>
        /// <param name="val">The value to match it against</param>
        /// <returns></returns>
        protected bool Match(string val)
        {
            return Match(val, null);
        }

        /// <summary>
        /// Tries to consume a token of the given type
        /// </summary>
        /// <param name="val">The value of the token, can be null to ignore</param>
        /// <param name="type">The type of the token, can be null to ignore</param>
        /// <returns>A bool signifying if the symbol could be matched or not</returns>
        protected bool Match(string val, Lexer.Token.TokenType? type)
        {
            bool ok = true;

            if (val != null && lookahead.Value != val)
                ok = false;
            else if (type.HasValue && lookahead.Type != type.Value)
                ok = false;

            if (!ok)
                SyntaxError(string.Format("{0}: expected '{1}', got instead '{2}', a {3}",
                    lookahead.Line, val ?? type.Value.ToString(), lookahead.Value, lookahead.Type.ToString()));

            if (lookahead.Type != Lexer.Token.TokenType.EndOfFile)
                lookahead = lexer.GetNextToken();

            return ok;
        }
    }
}
