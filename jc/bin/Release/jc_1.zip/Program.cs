﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace jc
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Count() < 1)
            {
                Console.WriteLine("Usage: jc source.jc");
                return;
            }

            Lexer lexer = new Lexer(File.OpenRead(args[0]));

            Lexer.Token token;
            while ((token = lexer.GetNextToken()).Type != Lexer.Token.TokenType.EndOfFile)
            {
                Console.WriteLine(string.Format("Token '{0}' of type {1} on line {2}",
                    token.Value, token.Type.ToString(), token.Line));
                if (token.Type == Lexer.Token.TokenType.Error)
                    Console.WriteLine(string.Format("*** Error reading token '{0}' on line {1}",
                        token.Value, token.Line));
            }
        }
    }
}
